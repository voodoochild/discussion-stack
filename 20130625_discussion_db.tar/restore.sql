create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'LATIN1';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT user_id_refs_id_f2045483;
ALTER TABLE ONLY public.moderation_moderatorprofile DROP CONSTRAINT user_id_refs_id_aa8f4260723c358;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT user_id_refs_id_831107f1;
ALTER TABLE ONLY public.moderation_sanction DROP CONSTRAINT user_id_refs_id_36d0b8b98643dc9c;
ALTER TABLE ONLY public.comments_discussion_tags DROP CONSTRAINT tag_id_refs_id_416d1f571c22ab47;
ALTER TABLE ONLY public.switchboard_state DROP CONSTRAINT switch_id_refs_id_476f89ab98f8aa25;
ALTER TABLE ONLY public.comments_namespace DROP CONSTRAINT site_id_refs_id_448b353ed306902d;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT sanction_id_refs_id_7810128a16f08192;
ALTER TABLE ONLY public.moderation_abusereport DROP CONSTRAINT reported_by_id_refs_id_37217111265eb8dc;
ALTER TABLE ONLY public.recommendations_recommendation DROP CONSTRAINT recommended_by_id_refs_id_4e1baccaf2495e47;
ALTER TABLE ONLY public.importer_pluckimportedrecommendation DROP CONSTRAINT recommendation_id_refs_id_174bc773ddf8ccaa;
ALTER TABLE ONLY public.importer_pluckimportedrating DROP CONSTRAINT rating_id_refs_id_5b950fa78b71c4df;
ALTER TABLE ONLY public.comments_rating DROP CONSTRAINT rated_by_id_refs_id_5d430b6ad4483d0a;
ALTER TABLE ONLY public.moderation_queues_moderationrequest DROP CONSTRAINT queue_id_refs_id_6e16697e04b41287;
ALTER TABLE ONLY public.moderation_moderatorprofile DROP CONSTRAINT profile_id_refs_id_70ace7459b768625;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT profile_id_refs_id_5f2b48735f55f457;
ALTER TABLE ONLY public.profiles_profile_badges DROP CONSTRAINT profile_id_refs_id_4f6dcb4bf49e90d1;
ALTER TABLE ONLY public.avatars_avatar DROP CONSTRAINT profile_id_refs_id_24e6856d7bf25f6b;
ALTER TABLE ONLY public.comments_discussion DROP CONSTRAINT primary_tag_id_refs_id_698f495bb834ed0c;
ALTER TABLE ONLY public.comments_comment DROP CONSTRAINT posted_by_id_refs_id_2c9ac73586c3c6fb;
ALTER TABLE ONLY public.comments_discussion DROP CONSTRAINT namespace_id_refs_id_fd1b9a43cd4e3cd;
ALTER TABLE ONLY public.comments_tag DROP CONSTRAINT namespace_id_refs_id_535b042a1cd85e34;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT moderator_id_refs_id_6b5a2258500626ec;
ALTER TABLE ONLY public.moderation_ipaddressnotes DROP CONSTRAINT moderator_id_refs_id_49788360712e942a;
ALTER TABLE ONLY public.moderation_ipsblockedfromreportingabuse DROP CONSTRAINT moderator_id_refs_id_4530472607be015e;
ALTER TABLE ONLY public.moderation_queues_moderationrequest DROP CONSTRAINT moderator_id_refs_id_3f3a2f5954a9e9e2;
ALTER TABLE ONLY public.comments_discussion DROP CONSTRAINT latest_visible_comment_id_refs_id_1fca803b6e61b527;
ALTER TABLE ONLY public.comments_commenthighlight DROP CONSTRAINT highlighted_by_id_refs_id_4480c5be3b069bfa;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT group_id_refs_id_3cea63fe;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_fkey;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_fkey;
ALTER TABLE ONLY public.moderation_queues_moderationrequest DROP CONSTRAINT discussion_id_refs_id_b297a5a878a7d4b;
ALTER TABLE ONLY public.comments_rating DROP CONSTRAINT discussion_id_refs_id_4acaede2360ed6dc;
ALTER TABLE ONLY public.comments_discussion_tags DROP CONSTRAINT discussion_id_refs_id_449eaad17fc7f532;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT discussion_id_refs_id_380556b396e63071;
ALTER TABLE ONLY public.comments_comment DROP CONSTRAINT discussion_id_refs_id_26a61b8ebd46315;
ALTER TABLE ONLY public.profiles_profile DROP CONSTRAINT current_avatar_id_refs_id_5e2be1fbe11cf5db;
ALTER TABLE ONLY public.comments_discussion DROP CONSTRAINT creating_comment_id_refs_id_1fca803b6e61b527;
ALTER TABLE ONLY public.antispam_badword DROP CONSTRAINT created_by_id_refs_id_37574aff78f4ce57;
ALTER TABLE ONLY public.moderation_sanction DROP CONSTRAINT created_by_id_refs_id_11c9b6321c566ce1;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT content_type_id_refs_id_728de91f;
ALTER TABLE ONLY public.comments_commenthighlight DROP CONSTRAINT comment_posted_by_id_refs_id_4480c5be3b069bfa;
ALTER TABLE ONLY public.importer_pluckimportedcomment DROP CONSTRAINT comment_id_refs_id_68dbaee279080207;
ALTER TABLE ONLY public.recommendations_recommendation DROP CONSTRAINT comment_id_refs_id_653e891137f9a181;
ALTER TABLE ONLY public.importer_pluckimportedreview DROP CONSTRAINT comment_id_refs_id_6441e2cf0e269e43;
ALTER TABLE ONLY public.comments_commentrecommendations DROP CONSTRAINT comment_id_refs_id_4f0a8e25c3bfa4f4;
ALTER TABLE ONLY public.moderation_abusereport DROP CONSTRAINT comment_id_refs_id_28ed674d7b1b4724;
ALTER TABLE ONLY public.moderation_queues_moderationrequest DROP CONSTRAINT comment_id_refs_id_27b7ee8904c1b13;
ALTER TABLE ONLY public.comments_commenthighlight DROP CONSTRAINT comment_id_refs_id_2211788ac1c891f2;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT comment_id_refs_id_1dd01da63e55c731;
ALTER TABLE ONLY public.moderation_abusereport DROP CONSTRAINT category_id_refs_id_26aa4fe00b91cbc9;
ALTER TABLE ONLY public.profiles_profile_badges DROP CONSTRAINT badge_id_refs_id_53b95d8cb3e69a35;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT avatar_id_refs_id_466e633decfc5f81;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_permission_id_fkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_fkey;
ALTER TABLE ONLY public.auth_message DROP CONSTRAINT auth_message_user_id_fkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_permission_id_fkey;
ALTER TABLE ONLY public.importer_pluckimportedcomment DROP CONSTRAINT action_id_refs_id_12bb42afd1257175;
ALTER TABLE ONLY public.moderation_abusereport DROP CONSTRAINT accused_id_refs_id_37217111265eb8dc;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT abuse_report_id_refs_id_2988495895dddc2e;
DROP INDEX public.switchboard_state_switch_id;
DROP INDEX public.recommendations_recommendation_recommended_by_id;
DROP INDEX public.recommendations_recommendation_comment_id;
DROP INDEX public.profiles_profile_vanity_url;
DROP INDEX public.profiles_profile_user_id;
DROP INDEX public.profiles_profile_total_comment_count;
DROP INDEX public.profiles_profile_last_ip_address_like;
DROP INDEX public.profiles_profile_last_ip_address;
DROP INDEX public.profiles_profile_is_social;
DROP INDEX public.profiles_profile_current_avatar_id;
DROP INDEX public.profiles_profile_created_on;
DROP INDEX public.profiles_profile_badges_profile_id;
DROP INDEX public.profiles_profile_badges_badge_id;
DROP INDEX public.moderation_sanction_user_id;
DROP INDEX public.moderation_sanction_sanction_until;
DROP INDEX public.moderation_sanction_sanction_type_like;
DROP INDEX public.moderation_sanction_sanction_type;
DROP INDEX public.moderation_sanction_created_by_id;
DROP INDEX public.moderation_queues_moderationrequest_queue_id;
DROP INDEX public.moderation_queues_moderationrequest_moderator_id;
DROP INDEX public.moderation_queues_moderationrequest_discussion_id;
DROP INDEX public.moderation_moderatorprofile_user_id;
DROP INDEX public.moderation_moderatorprofile_profile_id;
DROP INDEX public.moderation_ipsblockedfromreportingabuse_moderator_id;
DROP INDEX public.moderation_ipsblockedfromreportingabuse_ip_like;
DROP INDEX public.moderation_ipsblockedfromreportingabuse_ip;
DROP INDEX public.moderation_ipaddressnotes_moderator_id;
DROP INDEX public.moderation_ipaddressnotes_ip_address_like;
DROP INDEX public.moderation_ipaddressnotes_ip_address;
DROP INDEX public.moderation_action_sanction_id;
DROP INDEX public.moderation_action_profile_id;
DROP INDEX public.moderation_action_moderator_id;
DROP INDEX public.moderation_action_discussion_id;
DROP INDEX public.moderation_action_created_at;
DROP INDEX public.moderation_action_comment_id;
DROP INDEX public.moderation_action_avatar_id;
DROP INDEX public.moderation_action_abuse_report_id;
DROP INDEX public.moderation_abusereport_status_like;
DROP INDEX public.moderation_abusereport_status;
DROP INDEX public.moderation_abusereport_reported_by_id;
DROP INDEX public.moderation_abusereport_created_at;
DROP INDEX public.moderation_abusereport_comment_id;
DROP INDEX public.moderation_abusereport_category_id;
DROP INDEX public.moderation_abusereport_accused_id;
DROP INDEX public.importer_pluckimportedrating_rating_id;
DROP INDEX public.django_admin_log_user_id;
DROP INDEX public.django_admin_log_content_type_id;
DROP INDEX public.comments_tag_path_like;
DROP INDEX public.comments_tag_path;
DROP INDEX public.comments_tag_namespace_id;
DROP INDEX public.comments_tag_last_updated;
DROP INDEX public.comments_rating_rated_by_id;
DROP INDEX public.comments_rating_last_updated;
DROP INDEX public.comments_rating_discussion_id;
DROP INDEX public.comments_namespace_site_id;
DROP INDEX public.comments_discussion_tags_tag_id;
DROP INDEX public.comments_discussion_tags_discussion_id;
DROP INDEX public.comments_discussion_status_like;
DROP INDEX public.comments_discussion_status;
DROP INDEX public.comments_discussion_primary_tag_id;
DROP INDEX public.comments_discussion_namespace_id;
DROP INDEX public.comments_discussion_latest_visible_comment_id_456d723de093b44a;
DROP INDEX public.comments_discussion_latest_visible_comment_id;
DROP INDEX public.comments_discussion_last_updated;
DROP INDEX public.comments_discussion_creating_comment_id;
DROP INDEX public.comments_discussion_created_on;
DROP INDEX public.comments_discussion_closed_after;
DROP INDEX public.comments_commenthighlight_highlighted_by_id;
DROP INDEX public.comments_commenthighlight_comment_posted_by_id;
DROP INDEX public.comments_commenthighlight_comment_id;
DROP INDEX public.comments_comment_status_like;
DROP INDEX public.comments_comment_status;
DROP INDEX public.comments_comment_posted_by_ip_like;
DROP INDEX public.comments_comment_posted_by_ip;
DROP INDEX public.comments_comment_posted_by_id_34f5d0d83981371;
DROP INDEX public.comments_comment_posted_by_id;
DROP INDEX public.comments_comment_last_updated;
DROP INDEX public.comments_comment_is_flagged;
DROP INDEX public.comments_comment_in_reply_to_id;
DROP INDEX public.comments_comment_dn_in_reply_to_profile_id;
DROP INDEX public.comments_comment_discussion_id_3a4da9d2e640130f;
DROP INDEX public.comments_comment_discussion_id_38e24964784b4e6f;
DROP INDEX public.comments_comment_discussion_id;
DROP INDEX public.comments_comment_created_on;
DROP INDEX public.comments_comment_common_ancestor_id;
DROP INDEX public.cachetable_expires;
DROP INDEX public.avatars_avatar_status_like;
DROP INDEX public.avatars_avatar_status;
DROP INDEX public.avatars_avatar_requires_moderation;
DROP INDEX public.avatars_avatar_profile_id;
DROP INDEX public.avatars_avatar_is_communal;
DROP INDEX public.avatars_avatar_created_on;
DROP INDEX public.auth_user_user_permissions_user_id;
DROP INDEX public.auth_user_user_permissions_permission_id;
DROP INDEX public.auth_user_groups_user_id;
DROP INDEX public.auth_user_groups_group_id;
DROP INDEX public.auth_permission_content_type_id;
DROP INDEX public.auth_message_user_id;
DROP INDEX public.auth_group_permissions_permission_id;
DROP INDEX public.auth_group_permissions_group_id;
DROP INDEX public.antispam_badword_created_by_id;
ALTER TABLE ONLY public.switchboard_switch DROP CONSTRAINT switchboard_switch_pkey;
ALTER TABLE ONLY public.switchboard_switch DROP CONSTRAINT switchboard_switch_name_uniq;
ALTER TABLE ONLY public.switchboard_state DROP CONSTRAINT switchboard_state_pkey;
ALTER TABLE ONLY public.south_migrationhistory DROP CONSTRAINT south_migrationhistory_pkey;
ALTER TABLE ONLY public.recommendations_recommendation DROP CONSTRAINT recommendations_recommendation_pkey;
ALTER TABLE ONLY public.profiles_profile DROP CONSTRAINT profiles_profile_vanity_url_key;
ALTER TABLE ONLY public.profiles_profile DROP CONSTRAINT profiles_profile_user_id_key;
ALTER TABLE ONLY public.profiles_profile DROP CONSTRAINT profiles_profile_pkey;
ALTER TABLE ONLY public.profiles_profile_badges DROP CONSTRAINT profiles_profile_badges_profile_id_2c36ddcdf89ea09a_uniq;
ALTER TABLE ONLY public.profiles_profile_badges DROP CONSTRAINT profiles_profile_badges_pkey;
ALTER TABLE ONLY public.profiles_badge DROP CONSTRAINT profiles_badge_pkey;
ALTER TABLE ONLY public.moderation_sanction DROP CONSTRAINT moderation_sanction_pkey;
ALTER TABLE ONLY public.moderation_queues_moderationrequest DROP CONSTRAINT moderation_queues_moderationrequest_request_hash_uniq;
ALTER TABLE ONLY public.moderation_queues_moderationrequest DROP CONSTRAINT moderation_queues_moderationrequest_pkey;
ALTER TABLE ONLY public.moderation_queues_moderationqueue DROP CONSTRAINT moderation_queues_moderationqueue_pkey;
ALTER TABLE ONLY public.moderation_queues_moderationqueue DROP CONSTRAINT moderation_queues_moderationqueue_code_uniq;
ALTER TABLE ONLY public.moderation_moderatorprofile DROP CONSTRAINT moderation_moderatorprofile_pkey;
ALTER TABLE ONLY public.moderation_ipsblockedfromreportingabuse DROP CONSTRAINT moderation_ipsblockedfromreportingabuse_pkey;
ALTER TABLE ONLY public.moderation_ipaddressnotes DROP CONSTRAINT moderation_ipaddressnotes_pkey;
ALTER TABLE ONLY public.moderation_applicationpermissions DROP CONSTRAINT moderation_applicationpermissions_pkey;
ALTER TABLE ONLY public.moderation_action DROP CONSTRAINT moderation_action_pkey;
ALTER TABLE ONLY public.moderation_abusereport DROP CONSTRAINT moderation_abusereport_pkey;
ALTER TABLE ONLY public.moderation_abusecategory DROP CONSTRAINT moderation_abusecategory_pkey;
ALTER TABLE ONLY public.jogging_log DROP CONSTRAINT jogging_log_pkey;
ALTER TABLE ONLY public.importer_pluckimportedreview DROP CONSTRAINT importer_pluckimportedreview_pluck_review_key_key;
ALTER TABLE ONLY public.importer_pluckimportedreview DROP CONSTRAINT importer_pluckimportedreview_pkey;
ALTER TABLE ONLY public.importer_pluckimportedreview DROP CONSTRAINT importer_pluckimportedreview_comment_id_key;
ALTER TABLE ONLY public.importer_pluckimportedrecommendation DROP CONSTRAINT importer_pluckimportedrecommendation_pkey;
ALTER TABLE ONLY public.importer_pluckimportedrecommendation DROP CONSTRAINT importer_pluckimportedrecommendati_pluck_recommendation_key_key;
ALTER TABLE ONLY public.importer_pluckimportedrating DROP CONSTRAINT importer_pluckimportedrating_pluck_rating_key_key;
ALTER TABLE ONLY public.importer_pluckimportedrating DROP CONSTRAINT importer_pluckimportedrating_pkey;
ALTER TABLE ONLY public.importer_pluckimportedcomment DROP CONSTRAINT importer_pluckimportedcomment_pluck_comment_key_key;
ALTER TABLE ONLY public.importer_pluckimportedcomment DROP CONSTRAINT importer_pluckimportedcomment_pkey;
ALTER TABLE ONLY public.importer_pluckimportedcomment DROP CONSTRAINT importer_pluckimportedcomment_comment_id_key;
ALTER TABLE ONLY public.importer_pluckimportedcomment DROP CONSTRAINT importer_pluckimportedcomment_action_id_key;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_key;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.comments_tag DROP CONSTRAINT comments_tag_pkey;
ALTER TABLE ONLY public.comments_tag DROP CONSTRAINT comments_tag_namespace_id_681b0d0b7e158899_uniq;
ALTER TABLE ONLY public.comments_rating DROP CONSTRAINT comments_rating_pkey;
ALTER TABLE ONLY public.comments_rating DROP CONSTRAINT comments_rating_discussion_id_548f5958da064c9_uniq;
ALTER TABLE ONLY public.comments_namespace DROP CONSTRAINT comments_namespace_pkey;
ALTER TABLE ONLY public.comments_namespace DROP CONSTRAINT comments_namespace_name_key;
ALTER TABLE ONLY public.comments_discussion_tags DROP CONSTRAINT comments_discussion_tags_pkey;
ALTER TABLE ONLY public.comments_discussion_tags DROP CONSTRAINT comments_discussion_tags_discussion_id_4e76b889f0b6619c_uniq;
ALTER TABLE ONLY public.comments_discussion DROP CONSTRAINT comments_discussion_pkey;
ALTER TABLE ONLY public.comments_discussion DROP CONSTRAINT comments_discussion_namespace_id_1e11383113e1ee6d_uniq;
ALTER TABLE ONLY public.comments_discussion DROP CONSTRAINT comments_discussion_key_key;
ALTER TABLE ONLY public.comments_commentrecommendations DROP CONSTRAINT comments_commentrecommendations_pkey;
ALTER TABLE ONLY public.comments_commentrecommendations DROP CONSTRAINT comments_commentrecommendations_comment_id_key;
ALTER TABLE ONLY public.comments_commenthighlight DROP CONSTRAINT comments_commenthighlight_pkey;
ALTER TABLE ONLY public.comments_comment DROP CONSTRAINT comments_comment_pkey;
ALTER TABLE ONLY public.cachetable DROP CONSTRAINT cachetable_pkey;
ALTER TABLE ONLY public.avatars_avatar DROP CONSTRAINT avatars_avatar_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_key;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_key;
ALTER TABLE ONLY public.auth_message DROP CONSTRAINT auth_message_pkey;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE ONLY public.antispam_badword DROP CONSTRAINT antispam_badword_pkey;
ALTER TABLE public.switchboard_switch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.switchboard_state ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.south_migrationhistory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.recommendations_recommendation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.profiles_profile_badges ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.profiles_profile ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.profiles_badge ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_sanction ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_queues_moderationrequest ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_queues_moderationqueue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_moderatorprofile ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_ipsblockedfromreportingabuse ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_ipaddressnotes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_applicationpermissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_action ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_abusereport ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.moderation_abusecategory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.jogging_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.importer_pluckimportedreview ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.importer_pluckimportedrecommendation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.importer_pluckimportedrating ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.importer_pluckimportedcomment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_tag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_rating ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_namespace ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_discussion_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_discussion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_commentrecommendations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_commenthighlight ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments_comment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.avatars_avatar ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_message ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.antispam_badword ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.switchboard_switch_id_seq;
DROP TABLE public.switchboard_switch;
DROP SEQUENCE public.switchboard_state_id_seq;
DROP TABLE public.switchboard_state;
DROP SEQUENCE public.south_migrationhistory_id_seq;
DROP TABLE public.south_migrationhistory;
DROP SEQUENCE public.recommendations_recommendation_id_seq;
DROP TABLE public.recommendations_recommendation;
DROP SEQUENCE public.profiles_profile_id_seq;
DROP SEQUENCE public.profiles_profile_badges_id_seq;
DROP TABLE public.profiles_profile_badges;
DROP TABLE public.profiles_profile;
DROP SEQUENCE public.profiles_badge_id_seq;
DROP TABLE public.profiles_badge;
DROP SEQUENCE public.moderation_sanction_id_seq;
DROP TABLE public.moderation_sanction;
DROP SEQUENCE public.moderation_queues_moderationrequest_id_seq;
DROP TABLE public.moderation_queues_moderationrequest;
DROP SEQUENCE public.moderation_queues_moderationqueue_id_seq;
DROP TABLE public.moderation_queues_moderationqueue;
DROP SEQUENCE public.moderation_moderatorprofile_id_seq;
DROP TABLE public.moderation_moderatorprofile;
DROP SEQUENCE public.moderation_ipsblockedfromreportingabuse_id_seq;
DROP TABLE public.moderation_ipsblockedfromreportingabuse;
DROP SEQUENCE public.moderation_ipaddressnotes_id_seq;
DROP TABLE public.moderation_ipaddressnotes;
DROP SEQUENCE public.moderation_applicationpermissions_id_seq;
DROP TABLE public.moderation_applicationpermissions;
DROP SEQUENCE public.moderation_action_id_seq;
DROP TABLE public.moderation_action;
DROP SEQUENCE public.moderation_abusereport_id_seq;
DROP TABLE public.moderation_abusereport;
DROP SEQUENCE public.moderation_abusecategory_id_seq;
DROP TABLE public.moderation_abusecategory;
DROP SEQUENCE public.jogging_log_id_seq;
DROP TABLE public.jogging_log;
DROP SEQUENCE public.importer_pluckimportedreview_id_seq;
DROP TABLE public.importer_pluckimportedreview;
DROP SEQUENCE public.importer_pluckimportedrecommendation_id_seq;
DROP TABLE public.importer_pluckimportedrecommendation;
DROP SEQUENCE public.importer_pluckimportedrating_id_seq;
DROP TABLE public.importer_pluckimportedrating;
DROP SEQUENCE public.importer_pluckimportedcomment_id_seq;
DROP TABLE public.importer_pluckimportedcomment;
DROP SEQUENCE public.django_site_id_seq;
DROP TABLE public.django_site;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.comments_tag_id_seq;
DROP TABLE public.comments_tag;
DROP SEQUENCE public.comments_rating_id_seq;
DROP TABLE public.comments_rating;
DROP SEQUENCE public.comments_namespace_id_seq;
DROP TABLE public.comments_namespace;
DROP SEQUENCE public.comments_discussion_tags_id_seq;
DROP TABLE public.comments_discussion_tags;
DROP SEQUENCE public.comments_discussion_id_seq;
DROP TABLE public.comments_discussion;
DROP SEQUENCE public.comments_commentrecommendations_id_seq;
DROP TABLE public.comments_commentrecommendations;
DROP SEQUENCE public.comments_commenthighlight_id_seq;
DROP TABLE public.comments_commenthighlight;
DROP SEQUENCE public.comments_comment_id_seq;
DROP TABLE public.comments_comment;
DROP TABLE public.cachetable;
DROP SEQUENCE public.avatars_avatar_id_seq;
DROP TABLE public.avatars_avatar;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_message_id_seq;
DROP TABLE public.auth_message;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP SEQUENCE public.antispam_badword_id_seq;
DROP TABLE public.antispam_badword;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: antispam_badword; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE antispam_badword (
    link_urls_only boolean DEFAULT true NOT NULL,
    word character varying(255) NOT NULL,
    id integer NOT NULL,
    created_by_id integer NOT NULL,
    created timestamp with time zone NOT NULL
);


ALTER TABLE public.antispam_badword OWNER TO pgowner;

--
-- Name: antispam_badword_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE antispam_badword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.antispam_badword_id_seq OWNER TO pgowner;

--
-- Name: antispam_badword_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE antispam_badword_id_seq OWNED BY antispam_badword.id;


--
-- Name: antispam_badword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('antispam_badword_id_seq', 1, false);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO pgowner;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO pgowner;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO pgowner;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO pgowner;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_message; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE auth_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.auth_message OWNER TO pgowner;

--
-- Name: auth_message_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE auth_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_message_id_seq OWNER TO pgowner;

--
-- Name: auth_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE auth_message_id_seq OWNED BY auth_message.id;


--
-- Name: auth_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('auth_message_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO pgowner;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO pgowner;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('auth_permission_id_seq', 124, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO pgowner;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO pgowner;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO pgowner;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO pgowner;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('auth_user_id_seq', 2, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO pgowner;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO pgowner;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: avatars_avatar; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE avatars_avatar (
    status character varying(20) DEFAULT 'new'::character varying NOT NULL,
    created_on timestamp with time zone DEFAULT '2011-11-15 14:48:06.835478+00'::timestamp with time zone NOT NULL,
    id integer NOT NULL,
    original_filename character varying(255) DEFAULT ''::character varying NOT NULL,
    image_filename character varying(255) NOT NULL,
    profile_id integer NOT NULL,
    is_communal boolean NOT NULL,
    requires_moderation boolean
);


ALTER TABLE public.avatars_avatar OWNER TO pgowner;

--
-- Name: avatars_avatar_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE avatars_avatar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.avatars_avatar_id_seq OWNER TO pgowner;

--
-- Name: avatars_avatar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE avatars_avatar_id_seq OWNED BY avatars_avatar.id;


--
-- Name: avatars_avatar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('avatars_avatar_id_seq', 1, false);


--
-- Name: cachetable; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE cachetable (
    cache_key character varying(255) NOT NULL,
    value text NOT NULL,
    expires timestamp with time zone NOT NULL
);


ALTER TABLE public.cachetable OWNER TO pgowner;

--
-- Name: comments_comment; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_comment (
    body text NOT NULL,
    title character varying(255) DEFAULT ''::character varying NOT NULL,
    discussion_id integer NOT NULL,
    status character varying(20) DEFAULT 'visible'::character varying NOT NULL,
    body_original text,
    is_flagged boolean DEFAULT false NOT NULL,
    created_on timestamp with time zone DEFAULT '2011-11-15 14:48:07.684353+00'::timestamp with time zone NOT NULL,
    posted_by_ip character varying(32),
    id integer NOT NULL,
    posted_by_id integer NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    in_reply_to_id integer,
    dn_total_reply_count integer,
    dn_reply_to_comment_username text,
    dn_reply_to_comment_time timestamp with time zone,
    common_ancestor_id integer,
    dn_in_reply_to_profile_id integer
);


ALTER TABLE public.comments_comment OWNER TO pgowner;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_comment_id_seq OWNER TO pgowner;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_comment_id_seq OWNED BY comments_comment.id;


--
-- Name: comments_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_comment_id_seq', 10608, true);


--
-- Name: comments_commenthighlight; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_commenthighlight (
    id integer NOT NULL,
    comment_id integer NOT NULL,
    highlighted_by_id integer NOT NULL,
    created_on timestamp with time zone DEFAULT '2012-01-30 10:26:04.990247+00'::timestamp with time zone NOT NULL,
    comment_posted_by_id integer NOT NULL
);


ALTER TABLE public.comments_commenthighlight OWNER TO pgowner;

--
-- Name: comments_commenthighlight_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_commenthighlight_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_commenthighlight_id_seq OWNER TO pgowner;

--
-- Name: comments_commenthighlight_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_commenthighlight_id_seq OWNED BY comments_commenthighlight.id;


--
-- Name: comments_commenthighlight_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_commenthighlight_id_seq', 172, true);


--
-- Name: comments_commentrecommendations; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_commentrecommendations (
    comment_id integer NOT NULL,
    dn_anonymous_recommendation_count integer DEFAULT 0 NOT NULL,
    dn_registered_recommendation_count integer DEFAULT 0 NOT NULL,
    id integer NOT NULL,
    initial_index boolean
);


ALTER TABLE public.comments_commentrecommendations OWNER TO pgowner;

--
-- Name: comments_commentrecommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_commentrecommendations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_commentrecommendations_id_seq OWNER TO pgowner;

--
-- Name: comments_commentrecommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_commentrecommendations_id_seq OWNED BY comments_commentrecommendations.id;


--
-- Name: comments_commentrecommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_commentrecommendations_id_seq', 10608, true);


--
-- Name: comments_discussion; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_discussion (
    primary_tag_id integer,
    closed_after timestamp with time zone,
    url character varying(200) DEFAULT ''::character varying NOT NULL,
    premoderated boolean DEFAULT false NOT NULL,
    title character varying(255) DEFAULT ''::character varying NOT NULL,
    namespace_id integer NOT NULL,
    created_on timestamp with time zone DEFAULT '2011-11-15 14:48:07.514318+00'::timestamp with time zone NOT NULL,
    dn_total_comment_count integer DEFAULT 0 NOT NULL,
    key character varying(255) NOT NULL,
    id integer NOT NULL,
    dn_invisible_comment_count integer NOT NULL,
    anon_user_rating_count integer NOT NULL,
    anon_user_rating_total integer NOT NULL,
    dn_reg_user_rating_count integer NOT NULL,
    dn_reg_user_rating_total integer NOT NULL,
    creating_comment_id integer,
    last_updated timestamp with time zone NOT NULL,
    latest_visible_comment_id integer,
    display_threaded boolean,
    dn_top_level_comment_count integer,
    status character varying(20),
    watched boolean
);


ALTER TABLE public.comments_discussion OWNER TO pgowner;

--
-- Name: comments_discussion_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_discussion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_discussion_id_seq OWNER TO pgowner;

--
-- Name: comments_discussion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_discussion_id_seq OWNED BY comments_discussion.id;


--
-- Name: comments_discussion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_discussion_id_seq', 20, true);


--
-- Name: comments_discussion_tags; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_discussion_tags (
    id integer NOT NULL,
    discussion_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.comments_discussion_tags OWNER TO pgowner;

--
-- Name: comments_discussion_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_discussion_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_discussion_tags_id_seq OWNER TO pgowner;

--
-- Name: comments_discussion_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_discussion_tags_id_seq OWNED BY comments_discussion_tags.id;


--
-- Name: comments_discussion_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_discussion_tags_id_seq', 166, true);


--
-- Name: comments_namespace; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_namespace (
    description text NOT NULL,
    id integer NOT NULL,
    name character varying(16) NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.comments_namespace OWNER TO pgowner;

--
-- Name: comments_namespace_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_namespace_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_namespace_id_seq OWNER TO pgowner;

--
-- Name: comments_namespace_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_namespace_id_seq OWNED BY comments_namespace.id;


--
-- Name: comments_namespace_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_namespace_id_seq', 5, true);


--
-- Name: comments_rating; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_rating (
    id integer NOT NULL,
    discussion_id integer NOT NULL,
    rated_by_id integer NOT NULL,
    last_updated timestamp with time zone DEFAULT '2011-11-15 14:48:11.099342+00'::timestamp with time zone NOT NULL,
    rating integer
);


ALTER TABLE public.comments_rating OWNER TO pgowner;

--
-- Name: comments_rating_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_rating_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_rating_id_seq OWNER TO pgowner;

--
-- Name: comments_rating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_rating_id_seq OWNED BY comments_rating.id;


--
-- Name: comments_rating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_rating_id_seq', 2, true);


--
-- Name: comments_tag; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE comments_tag (
    path character varying(255) NOT NULL,
    default_days_until_close integer,
    namespace_id integer NOT NULL,
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    forum_allowed boolean NOT NULL
);


ALTER TABLE public.comments_tag OWNER TO pgowner;

--
-- Name: comments_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE comments_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.comments_tag_id_seq OWNER TO pgowner;

--
-- Name: comments_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE comments_tag_id_seq OWNED BY comments_tag.id;


--
-- Name: comments_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('comments_tag_id_seq', 80, true);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO pgowner;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO pgowner;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO pgowner;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO pgowner;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('django_content_type_id_seq', 40, true);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO pgowner;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO pgowner;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO pgowner;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Name: importer_pluckimportedcomment; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE importer_pluckimportedcomment (
    comment_id integer,
    action_id integer,
    pluck_comment_key character varying(255) NOT NULL,
    id integer NOT NULL,
    imported_on timestamp with time zone NOT NULL
);


ALTER TABLE public.importer_pluckimportedcomment OWNER TO pgowner;

--
-- Name: importer_pluckimportedcomment_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE importer_pluckimportedcomment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.importer_pluckimportedcomment_id_seq OWNER TO pgowner;

--
-- Name: importer_pluckimportedcomment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE importer_pluckimportedcomment_id_seq OWNED BY importer_pluckimportedcomment.id;


--
-- Name: importer_pluckimportedcomment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('importer_pluckimportedcomment_id_seq', 1, false);


--
-- Name: importer_pluckimportedrating; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE importer_pluckimportedrating (
    id integer NOT NULL,
    rating_id integer,
    pluck_rating_key character varying(255) NOT NULL,
    imported_on timestamp with time zone NOT NULL
);


ALTER TABLE public.importer_pluckimportedrating OWNER TO pgowner;

--
-- Name: importer_pluckimportedrating_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE importer_pluckimportedrating_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.importer_pluckimportedrating_id_seq OWNER TO pgowner;

--
-- Name: importer_pluckimportedrating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE importer_pluckimportedrating_id_seq OWNED BY importer_pluckimportedrating.id;


--
-- Name: importer_pluckimportedrating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('importer_pluckimportedrating_id_seq', 1, false);


--
-- Name: importer_pluckimportedrecommendation; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE importer_pluckimportedrecommendation (
    pluck_recommendation_key character varying(255) NOT NULL,
    id integer NOT NULL,
    imported_on timestamp with time zone NOT NULL,
    recommendation_id integer
);


ALTER TABLE public.importer_pluckimportedrecommendation OWNER TO pgowner;

--
-- Name: importer_pluckimportedrecommendation_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE importer_pluckimportedrecommendation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.importer_pluckimportedrecommendation_id_seq OWNER TO pgowner;

--
-- Name: importer_pluckimportedrecommendation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE importer_pluckimportedrecommendation_id_seq OWNED BY importer_pluckimportedrecommendation.id;


--
-- Name: importer_pluckimportedrecommendation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('importer_pluckimportedrecommendation_id_seq', 1, false);


--
-- Name: importer_pluckimportedreview; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE importer_pluckimportedreview (
    comment_id integer NOT NULL,
    pluck_review_key character varying(255) NOT NULL,
    id integer NOT NULL,
    imported_on timestamp with time zone NOT NULL
);


ALTER TABLE public.importer_pluckimportedreview OWNER TO pgowner;

--
-- Name: importer_pluckimportedreview_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE importer_pluckimportedreview_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.importer_pluckimportedreview_id_seq OWNER TO pgowner;

--
-- Name: importer_pluckimportedreview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE importer_pluckimportedreview_id_seq OWNED BY importer_pluckimportedreview.id;


--
-- Name: importer_pluckimportedreview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('importer_pluckimportedreview_id_seq', 1, false);


--
-- Name: jogging_log; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE jogging_log (
    id integer NOT NULL,
    datetime timestamp with time zone NOT NULL,
    level character varying(128) NOT NULL,
    msg text NOT NULL,
    source character varying(128) NOT NULL,
    host character varying(200)
);


ALTER TABLE public.jogging_log OWNER TO pgowner;

--
-- Name: jogging_log_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE jogging_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.jogging_log_id_seq OWNER TO pgowner;

--
-- Name: jogging_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE jogging_log_id_seq OWNED BY jogging_log.id;


--
-- Name: jogging_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('jogging_log_id_seq', 1, false);


--
-- Name: moderation_abusecategory; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_abusecategory (
    description text NOT NULL,
    reason_required boolean DEFAULT false NOT NULL,
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.moderation_abusecategory OWNER TO pgowner;

--
-- Name: moderation_abusecategory_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_abusecategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_abusecategory_id_seq OWNER TO pgowner;

--
-- Name: moderation_abusecategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_abusecategory_id_seq OWNED BY moderation_abusecategory.id;


--
-- Name: moderation_abusecategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_abusecategory_id_seq', 9, true);


--
-- Name: moderation_abusereport; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_abusereport (
    category_id integer NOT NULL,
    comment_id integer,
    weight integer DEFAULT 0 NOT NULL,
    reported_by_id integer,
    created_on timestamp with time zone DEFAULT '2011-11-15 14:48:15.532456+00'::timestamp with time zone NOT NULL,
    url character varying(255),
    reason text,
    accused_id integer,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    email_address character varying(255),
    id integer NOT NULL,
    edit_url character varying(255),
    reported_by_ip text
);


ALTER TABLE public.moderation_abusereport OWNER TO pgowner;

--
-- Name: moderation_abusereport_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_abusereport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_abusereport_id_seq OWNER TO pgowner;

--
-- Name: moderation_abusereport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_abusereport_id_seq OWNED BY moderation_abusereport.id;


--
-- Name: moderation_abusereport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_abusereport_id_seq', 106, true);


--
-- Name: moderation_action; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_action (
    comment_id integer,
    profile_id integer,
    note text,
    created_on timestamp with time zone DEFAULT '2011-11-15 14:48:15.700785+00'::timestamp with time zone NOT NULL,
    abuse_report_id integer,
    moderator_id integer NOT NULL,
    avatar_id integer,
    sanction_id integer,
    type character varying(32) NOT NULL,
    id integer NOT NULL,
    discussion_id integer
);


ALTER TABLE public.moderation_action OWNER TO pgowner;

--
-- Name: moderation_action_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_action_id_seq OWNER TO pgowner;

--
-- Name: moderation_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_action_id_seq OWNED BY moderation_action.id;


--
-- Name: moderation_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_action_id_seq', 224, true);


--
-- Name: moderation_applicationpermissions; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_applicationpermissions (
    id integer NOT NULL,
    do_not_use integer
);


ALTER TABLE public.moderation_applicationpermissions OWNER TO pgowner;

--
-- Name: moderation_applicationpermissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_applicationpermissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_applicationpermissions_id_seq OWNER TO pgowner;

--
-- Name: moderation_applicationpermissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_applicationpermissions_id_seq OWNED BY moderation_applicationpermissions.id;


--
-- Name: moderation_applicationpermissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_applicationpermissions_id_seq', 1, false);


--
-- Name: moderation_ipaddressnotes; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_ipaddressnotes (
    id integer NOT NULL,
    moderator_id integer NOT NULL,
    created_on timestamp with time zone DEFAULT '2011-11-18 11:53:21.297069+00'::timestamp with time zone NOT NULL,
    note text,
    ip_address character varying(32),
    action text
);


ALTER TABLE public.moderation_ipaddressnotes OWNER TO pgowner;

--
-- Name: moderation_ipaddressnotes_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_ipaddressnotes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_ipaddressnotes_id_seq OWNER TO pgowner;

--
-- Name: moderation_ipaddressnotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_ipaddressnotes_id_seq OWNED BY moderation_ipaddressnotes.id;


--
-- Name: moderation_ipaddressnotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_ipaddressnotes_id_seq', 1, false);


--
-- Name: moderation_ipsblockedfromreportingabuse; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_ipsblockedfromreportingabuse (
    id integer NOT NULL,
    ip character varying(32),
    block_start timestamp with time zone NOT NULL,
    block_end timestamp with time zone NOT NULL,
    moderator_id integer NOT NULL
);


ALTER TABLE public.moderation_ipsblockedfromreportingabuse OWNER TO pgowner;

--
-- Name: moderation_ipsblockedfromreportingabuse_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_ipsblockedfromreportingabuse_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_ipsblockedfromreportingabuse_id_seq OWNER TO pgowner;

--
-- Name: moderation_ipsblockedfromreportingabuse_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_ipsblockedfromreportingabuse_id_seq OWNED BY moderation_ipsblockedfromreportingabuse.id;


--
-- Name: moderation_ipsblockedfromreportingabuse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_ipsblockedfromreportingabuse_id_seq', 1, false);


--
-- Name: moderation_moderatorprofile; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_moderatorprofile (
    profile_id integer NOT NULL,
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.moderation_moderatorprofile OWNER TO pgowner;

--
-- Name: moderation_moderatorprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_moderatorprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_moderatorprofile_id_seq OWNER TO pgowner;

--
-- Name: moderation_moderatorprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_moderatorprofile_id_seq OWNED BY moderation_moderatorprofile.id;


--
-- Name: moderation_moderatorprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_moderatorprofile_id_seq', 1, false);


--
-- Name: moderation_queues_moderationqueue; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_queues_moderationqueue (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL
);


ALTER TABLE public.moderation_queues_moderationqueue OWNER TO pgowner;

--
-- Name: moderation_queues_moderationqueue_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_queues_moderationqueue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_queues_moderationqueue_id_seq OWNER TO pgowner;

--
-- Name: moderation_queues_moderationqueue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_queues_moderationqueue_id_seq OWNED BY moderation_queues_moderationqueue.id;


--
-- Name: moderation_queues_moderationqueue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_queues_moderationqueue_id_seq', 5, true);


--
-- Name: moderation_queues_moderationrequest; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_queues_moderationrequest (
    id integer NOT NULL,
    queue_id integer NOT NULL,
    comment_id integer NOT NULL,
    expiry_time timestamp with time zone,
    created_on timestamp with time zone NOT NULL,
    priority integer,
    moderator_id integer,
    request_hash character varying(255),
    discussion_id integer,
    source_created_on timestamp with time zone NOT NULL
);


ALTER TABLE public.moderation_queues_moderationrequest OWNER TO pgowner;

--
-- Name: moderation_queues_moderationrequest_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_queues_moderationrequest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_queues_moderationrequest_id_seq OWNER TO pgowner;

--
-- Name: moderation_queues_moderationrequest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_queues_moderationrequest_id_seq OWNED BY moderation_queues_moderationrequest.id;


--
-- Name: moderation_queues_moderationrequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_queues_moderationrequest_id_seq', 544, true);


--
-- Name: moderation_sanction; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE moderation_sanction (
    created_on timestamp with time zone DEFAULT '2011-11-15 14:48:15.657092+00'::timestamp with time zone NOT NULL,
    sanction_until timestamp with time zone,
    created_by_id integer NOT NULL,
    note text NOT NULL,
    user_id integer NOT NULL,
    id integer NOT NULL,
    sanction_type character varying(20) DEFAULT 'banned'::character varying NOT NULL
);


ALTER TABLE public.moderation_sanction OWNER TO pgowner;

--
-- Name: moderation_sanction_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE moderation_sanction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.moderation_sanction_id_seq OWNER TO pgowner;

--
-- Name: moderation_sanction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE moderation_sanction_id_seq OWNED BY moderation_sanction.id;


--
-- Name: moderation_sanction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('moderation_sanction_id_seq', 17, true);


--
-- Name: profiles_badge; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE profiles_badge (
    abuse_report_weight integer DEFAULT 0 NOT NULL,
    image_url character varying(255) NOT NULL,
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    display_name character varying(80) NOT NULL
);


ALTER TABLE public.profiles_badge OWNER TO pgowner;

--
-- Name: profiles_badge_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE profiles_badge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.profiles_badge_id_seq OWNER TO pgowner;

--
-- Name: profiles_badge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE profiles_badge_id_seq OWNED BY profiles_badge.id;


--
-- Name: profiles_badge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('profiles_badge_id_seq', 3, true);


--
-- Name: profiles_profile; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE profiles_profile (
    username character varying(80) NOT NULL,
    interests text,
    current_avatar_id integer,
    user_id character varying(16) NOT NULL,
    lowercase_username character varying(80) NOT NULL,
    gender character varying(20) DEFAULT 'nodisplay'::character varying,
    last_updated_on timestamp with time zone NOT NULL,
    dob date,
    created_on timestamp with time zone DEFAULT '2011-11-15 14:48:07.091406+00'::timestamp with time zone NOT NULL,
    about_me text,
    location text,
    web_page character varying(255),
    real_name character varying(255),
    id integer NOT NULL,
    last_ip_address character varying(32),
    total_comment_count integer,
    pluck_avatar_url character varying(255),
    vanity_url character varying(80),
    is_social boolean,
    last_exported_on timestamp with time zone
);


ALTER TABLE public.profiles_profile OWNER TO pgowner;

--
-- Name: profiles_profile_badges; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE profiles_profile_badges (
    id integer NOT NULL,
    profile_id integer NOT NULL,
    badge_id integer NOT NULL
);


ALTER TABLE public.profiles_profile_badges OWNER TO pgowner;

--
-- Name: profiles_profile_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE profiles_profile_badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.profiles_profile_badges_id_seq OWNER TO pgowner;

--
-- Name: profiles_profile_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE profiles_profile_badges_id_seq OWNED BY profiles_profile_badges.id;


--
-- Name: profiles_profile_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('profiles_profile_badges_id_seq', 21, true);


--
-- Name: profiles_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE profiles_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.profiles_profile_id_seq OWNER TO pgowner;

--
-- Name: profiles_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE profiles_profile_id_seq OWNED BY profiles_profile.id;


--
-- Name: profiles_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('profiles_profile_id_seq', 15, true);


--
-- Name: recommendations_recommendation; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE recommendations_recommendation (
    comment_id integer NOT NULL,
    created_on timestamp with time zone DEFAULT '2010-06-15 11:40:34.949786+01'::timestamp with time zone NOT NULL,
    id integer NOT NULL,
    recommended_by_id integer
);


ALTER TABLE public.recommendations_recommendation OWNER TO pgowner;

--
-- Name: recommendations_recommendation_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE recommendations_recommendation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.recommendations_recommendation_id_seq OWNER TO pgowner;

--
-- Name: recommendations_recommendation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE recommendations_recommendation_id_seq OWNED BY recommendations_recommendation.id;


--
-- Name: recommendations_recommendation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('recommendations_recommendation_id_seq', 136, true);


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.south_migrationhistory OWNER TO pgowner;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.south_migrationhistory_id_seq OWNER TO pgowner;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 118, true);


--
-- Name: switchboard_state; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE switchboard_state (
    id integer NOT NULL,
    host character varying(80) NOT NULL,
    state boolean DEFAULT true NOT NULL,
    switch_id integer NOT NULL
);


ALTER TABLE public.switchboard_state OWNER TO pgowner;

--
-- Name: switchboard_state_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE switchboard_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.switchboard_state_id_seq OWNER TO pgowner;

--
-- Name: switchboard_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE switchboard_state_id_seq OWNED BY switchboard_state.id;


--
-- Name: switchboard_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('switchboard_state_id_seq', 7, true);


--
-- Name: switchboard_switch; Type: TABLE; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE TABLE switchboard_switch (
    id integer NOT NULL,
    name character varying(80) NOT NULL,
    description character varying(200) NOT NULL,
    default_state boolean NOT NULL
);


ALTER TABLE public.switchboard_switch OWNER TO pgowner;

--
-- Name: switchboard_switch_id_seq; Type: SEQUENCE; Schema: public; Owner: pgowner
--

CREATE SEQUENCE switchboard_switch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.switchboard_switch_id_seq OWNER TO pgowner;

--
-- Name: switchboard_switch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pgowner
--

ALTER SEQUENCE switchboard_switch_id_seq OWNED BY switchboard_switch.id;


--
-- Name: switchboard_switch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pgowner
--

SELECT pg_catalog.setval('switchboard_switch_id_seq', 7, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY antispam_badword ALTER COLUMN id SET DEFAULT nextval('antispam_badword_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_message ALTER COLUMN id SET DEFAULT nextval('auth_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY avatars_avatar ALTER COLUMN id SET DEFAULT nextval('avatars_avatar_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_comment ALTER COLUMN id SET DEFAULT nextval('comments_comment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_commenthighlight ALTER COLUMN id SET DEFAULT nextval('comments_commenthighlight_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_commentrecommendations ALTER COLUMN id SET DEFAULT nextval('comments_commentrecommendations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion ALTER COLUMN id SET DEFAULT nextval('comments_discussion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion_tags ALTER COLUMN id SET DEFAULT nextval('comments_discussion_tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_namespace ALTER COLUMN id SET DEFAULT nextval('comments_namespace_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_rating ALTER COLUMN id SET DEFAULT nextval('comments_rating_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_tag ALTER COLUMN id SET DEFAULT nextval('comments_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedcomment ALTER COLUMN id SET DEFAULT nextval('importer_pluckimportedcomment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedrating ALTER COLUMN id SET DEFAULT nextval('importer_pluckimportedrating_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedrecommendation ALTER COLUMN id SET DEFAULT nextval('importer_pluckimportedrecommendation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedreview ALTER COLUMN id SET DEFAULT nextval('importer_pluckimportedreview_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY jogging_log ALTER COLUMN id SET DEFAULT nextval('jogging_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_abusecategory ALTER COLUMN id SET DEFAULT nextval('moderation_abusecategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_abusereport ALTER COLUMN id SET DEFAULT nextval('moderation_abusereport_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action ALTER COLUMN id SET DEFAULT nextval('moderation_action_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_applicationpermissions ALTER COLUMN id SET DEFAULT nextval('moderation_applicationpermissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_ipaddressnotes ALTER COLUMN id SET DEFAULT nextval('moderation_ipaddressnotes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_ipsblockedfromreportingabuse ALTER COLUMN id SET DEFAULT nextval('moderation_ipsblockedfromreportingabuse_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_moderatorprofile ALTER COLUMN id SET DEFAULT nextval('moderation_moderatorprofile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_queues_moderationqueue ALTER COLUMN id SET DEFAULT nextval('moderation_queues_moderationqueue_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_queues_moderationrequest ALTER COLUMN id SET DEFAULT nextval('moderation_queues_moderationrequest_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_sanction ALTER COLUMN id SET DEFAULT nextval('moderation_sanction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY profiles_badge ALTER COLUMN id SET DEFAULT nextval('profiles_badge_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY profiles_profile ALTER COLUMN id SET DEFAULT nextval('profiles_profile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY profiles_profile_badges ALTER COLUMN id SET DEFAULT nextval('profiles_profile_badges_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY recommendations_recommendation ALTER COLUMN id SET DEFAULT nextval('recommendations_recommendation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY switchboard_state ALTER COLUMN id SET DEFAULT nextval('switchboard_state_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY switchboard_switch ALTER COLUMN id SET DEFAULT nextval('switchboard_switch_id_seq'::regclass);


--
-- Data for Name: antispam_badword; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY antispam_badword (link_urls_only, word, id, created_by_id, created) FROM stdin;
\.
copy antispam_badword (link_urls_only, word, id, created_by_id, created)  from '$$PATH$$/2445.dat' ;
--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY auth_group (id, name) FROM stdin;
\.
copy auth_group (id, name)  from '$$PATH$$/2416.dat' ;
--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
copy auth_group_permissions (id, group_id, permission_id)  from '$$PATH$$/2415.dat' ;
--
-- Data for Name: auth_message; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY auth_message (id, user_id, message) FROM stdin;
\.
copy auth_message (id, user_id, message)  from '$$PATH$$/2420.dat' ;
--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
copy auth_permission (id, name, content_type_id, codename)  from '$$PATH$$/2414.dat' ;
--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined) FROM stdin;
\.
copy auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined)  from '$$PATH$$/2419.dat' ;
--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
copy auth_user_groups (id, user_id, group_id)  from '$$PATH$$/2418.dat' ;
--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
copy auth_user_user_permissions (id, user_id, permission_id)  from '$$PATH$$/2417.dat' ;
--
-- Data for Name: avatars_avatar; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY avatars_avatar (status, created_on, id, original_filename, image_filename, profile_id, is_communal, requires_moderation) FROM stdin;
\.
copy avatars_avatar (status, created_on, id, original_filename, image_filename, profile_id, is_communal, requires_moderation)  from '$$PATH$$/2427.dat' ;
--
-- Data for Name: cachetable; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY cachetable (cache_key, value, expires) FROM stdin;
\.
copy cachetable (cache_key, value, expires)  from '$$PATH$$/2452.dat' ;
--
-- Data for Name: comments_comment; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_comment (body, title, discussion_id, status, body_original, is_flagged, created_on, posted_by_ip, id, posted_by_id, last_updated, in_reply_to_id, dn_total_reply_count, dn_reply_to_comment_username, dn_reply_to_comment_time, common_ancestor_id, dn_in_reply_to_profile_id) FROM stdin;
\.
copy comments_comment (body, title, discussion_id, status, body_original, is_flagged, created_on, posted_by_ip, id, posted_by_id, last_updated, in_reply_to_id, dn_total_reply_count, dn_reply_to_comment_username, dn_reply_to_comment_time, common_ancestor_id, dn_in_reply_to_profile_id)  from '$$PATH$$/2435.dat' ;
--
-- Data for Name: comments_commenthighlight; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_commenthighlight (id, comment_id, highlighted_by_id, created_on, comment_posted_by_id) FROM stdin;
\.
copy comments_commenthighlight (id, comment_id, highlighted_by_id, created_on, comment_posted_by_id)  from '$$PATH$$/2455.dat' ;
--
-- Data for Name: comments_commentrecommendations; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_commentrecommendations (comment_id, dn_anonymous_recommendation_count, dn_registered_recommendation_count, id, initial_index) FROM stdin;
\.
copy comments_commentrecommendations (comment_id, dn_anonymous_recommendation_count, dn_registered_recommendation_count, id, initial_index)  from '$$PATH$$/2436.dat' ;
--
-- Data for Name: comments_discussion; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_discussion (primary_tag_id, closed_after, url, premoderated, title, namespace_id, created_on, dn_total_comment_count, key, id, dn_invisible_comment_count, anon_user_rating_count, anon_user_rating_total, dn_reg_user_rating_count, dn_reg_user_rating_total, creating_comment_id, last_updated, latest_visible_comment_id, display_threaded, dn_top_level_comment_count, status, watched) FROM stdin;
\.
copy comments_discussion (primary_tag_id, closed_after, url, premoderated, title, namespace_id, created_on, dn_total_comment_count, key, id, dn_invisible_comment_count, anon_user_rating_count, anon_user_rating_total, dn_reg_user_rating_count, dn_reg_user_rating_total, creating_comment_id, last_updated, latest_visible_comment_id, display_threaded, dn_top_level_comment_count, status, watched)  from '$$PATH$$/2433.dat' ;
--
-- Data for Name: comments_discussion_tags; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_discussion_tags (id, discussion_id, tag_id) FROM stdin;
\.
copy comments_discussion_tags (id, discussion_id, tag_id)  from '$$PATH$$/2434.dat' ;
--
-- Data for Name: comments_namespace; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_namespace (description, id, name, site_id) FROM stdin;
\.
copy comments_namespace (description, id, name, site_id)  from '$$PATH$$/2431.dat' ;
--
-- Data for Name: comments_rating; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_rating (id, discussion_id, rated_by_id, last_updated, rating) FROM stdin;
\.
copy comments_rating (id, discussion_id, rated_by_id, last_updated, rating)  from '$$PATH$$/2437.dat' ;
--
-- Data for Name: comments_tag; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY comments_tag (path, default_days_until_close, namespace_id, id, name, last_updated, forum_allowed) FROM stdin;
\.
copy comments_tag (path, default_days_until_close, namespace_id, id, name, last_updated, forum_allowed)  from '$$PATH$$/2432.dat' ;
--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
\.
copy django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message)  from '$$PATH$$/2424.dat' ;
--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
\.
copy django_content_type (id, name, app_label, model)  from '$$PATH$$/2421.dat' ;
--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
copy django_session (session_key, session_data, expire_date)  from '$$PATH$$/2422.dat' ;
--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY django_site (id, domain, name) FROM stdin;
\.
copy django_site (id, domain, name)  from '$$PATH$$/2423.dat' ;
--
-- Data for Name: importer_pluckimportedcomment; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY importer_pluckimportedcomment (comment_id, action_id, pluck_comment_key, id, imported_on) FROM stdin;
\.
copy importer_pluckimportedcomment (comment_id, action_id, pluck_comment_key, id, imported_on)  from '$$PATH$$/2446.dat' ;
--
-- Data for Name: importer_pluckimportedrating; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY importer_pluckimportedrating (id, rating_id, pluck_rating_key, imported_on) FROM stdin;
\.
copy importer_pluckimportedrating (id, rating_id, pluck_rating_key, imported_on)  from '$$PATH$$/2449.dat' ;
--
-- Data for Name: importer_pluckimportedrecommendation; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY importer_pluckimportedrecommendation (pluck_recommendation_key, id, imported_on, recommendation_id) FROM stdin;
\.
copy importer_pluckimportedrecommendation (pluck_recommendation_key, id, imported_on, recommendation_id)  from '$$PATH$$/2448.dat' ;
--
-- Data for Name: importer_pluckimportedreview; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY importer_pluckimportedreview (comment_id, pluck_review_key, id, imported_on) FROM stdin;
\.
copy importer_pluckimportedreview (comment_id, pluck_review_key, id, imported_on)  from '$$PATH$$/2447.dat' ;
--
-- Data for Name: jogging_log; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY jogging_log (id, datetime, level, msg, source, host) FROM stdin;
\.
copy jogging_log (id, datetime, level, msg, source, host)  from '$$PATH$$/2426.dat' ;
--
-- Data for Name: moderation_abusecategory; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_abusecategory (description, reason_required, id, name) FROM stdin;
\.
copy moderation_abusecategory (description, reason_required, id, name)  from '$$PATH$$/2438.dat' ;
--
-- Data for Name: moderation_abusereport; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_abusereport (category_id, comment_id, weight, reported_by_id, created_on, url, reason, accused_id, status, email_address, id, edit_url, reported_by_ip) FROM stdin;
\.
copy moderation_abusereport (category_id, comment_id, weight, reported_by_id, created_on, url, reason, accused_id, status, email_address, id, edit_url, reported_by_ip)  from '$$PATH$$/2439.dat' ;
--
-- Data for Name: moderation_action; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_action (comment_id, profile_id, note, created_on, abuse_report_id, moderator_id, avatar_id, sanction_id, type, id, discussion_id) FROM stdin;
\.
copy moderation_action (comment_id, profile_id, note, created_on, abuse_report_id, moderator_id, avatar_id, sanction_id, type, id, discussion_id)  from '$$PATH$$/2442.dat' ;
--
-- Data for Name: moderation_applicationpermissions; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_applicationpermissions (id, do_not_use) FROM stdin;
\.
copy moderation_applicationpermissions (id, do_not_use)  from '$$PATH$$/2443.dat' ;
--
-- Data for Name: moderation_ipaddressnotes; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_ipaddressnotes (id, moderator_id, created_on, note, ip_address, action) FROM stdin;
\.
copy moderation_ipaddressnotes (id, moderator_id, created_on, note, ip_address, action)  from '$$PATH$$/2454.dat' ;
--
-- Data for Name: moderation_ipsblockedfromreportingabuse; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_ipsblockedfromreportingabuse (id, ip, block_start, block_end, moderator_id) FROM stdin;
\.
copy moderation_ipsblockedfromreportingabuse (id, ip, block_start, block_end, moderator_id)  from '$$PATH$$/2453.dat' ;
--
-- Data for Name: moderation_moderatorprofile; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_moderatorprofile (profile_id, id, user_id) FROM stdin;
\.
copy moderation_moderatorprofile (profile_id, id, user_id)  from '$$PATH$$/2440.dat' ;
--
-- Data for Name: moderation_queues_moderationqueue; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_queues_moderationqueue (id, name, code) FROM stdin;
\.
copy moderation_queues_moderationqueue (id, name, code)  from '$$PATH$$/2456.dat' ;
--
-- Data for Name: moderation_queues_moderationrequest; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_queues_moderationrequest (id, queue_id, comment_id, expiry_time, created_on, priority, moderator_id, request_hash, discussion_id, source_created_on) FROM stdin;
\.
copy moderation_queues_moderationrequest (id, queue_id, comment_id, expiry_time, created_on, priority, moderator_id, request_hash, discussion_id, source_created_on)  from '$$PATH$$/2457.dat' ;
--
-- Data for Name: moderation_sanction; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY moderation_sanction (created_on, sanction_until, created_by_id, note, user_id, id, sanction_type) FROM stdin;
\.
copy moderation_sanction (created_on, sanction_until, created_by_id, note, user_id, id, sanction_type)  from '$$PATH$$/2441.dat' ;
--
-- Data for Name: profiles_badge; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY profiles_badge (abuse_report_weight, image_url, id, name, display_name) FROM stdin;
\.
copy profiles_badge (abuse_report_weight, image_url, id, name, display_name)  from '$$PATH$$/2428.dat' ;
--
-- Data for Name: profiles_profile; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY profiles_profile (username, interests, current_avatar_id, user_id, lowercase_username, gender, last_updated_on, dob, created_on, about_me, location, web_page, real_name, id, last_ip_address, total_comment_count, pluck_avatar_url, vanity_url, is_social, last_exported_on) FROM stdin;
\.
copy profiles_profile (username, interests, current_avatar_id, user_id, lowercase_username, gender, last_updated_on, dob, created_on, about_me, location, web_page, real_name, id, last_ip_address, total_comment_count, pluck_avatar_url, vanity_url, is_social, last_exported_on)  from '$$PATH$$/2429.dat' ;
--
-- Data for Name: profiles_profile_badges; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY profiles_profile_badges (id, profile_id, badge_id) FROM stdin;
\.
copy profiles_profile_badges (id, profile_id, badge_id)  from '$$PATH$$/2430.dat' ;
--
-- Data for Name: recommendations_recommendation; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY recommendations_recommendation (comment_id, created_on, id, recommended_by_id) FROM stdin;
\.
copy recommendations_recommendation (comment_id, created_on, id, recommended_by_id)  from '$$PATH$$/2444.dat' ;
--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
\.
copy south_migrationhistory (id, app_name, migration, applied)  from '$$PATH$$/2425.dat' ;
--
-- Data for Name: switchboard_state; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY switchboard_state (id, host, state, switch_id) FROM stdin;
\.
copy switchboard_state (id, host, state, switch_id)  from '$$PATH$$/2451.dat' ;
--
-- Data for Name: switchboard_switch; Type: TABLE DATA; Schema: public; Owner: pgowner
--

COPY switchboard_switch (id, name, description, default_state) FROM stdin;
\.
copy switchboard_switch (id, name, description, default_state)  from '$$PATH$$/2450.dat' ;
--
-- Name: antispam_badword_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY antispam_badword
    ADD CONSTRAINT antispam_badword_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_message_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: avatars_avatar_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY avatars_avatar
    ADD CONSTRAINT avatars_avatar_pkey PRIMARY KEY (id);


--
-- Name: cachetable_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY cachetable
    ADD CONSTRAINT cachetable_pkey PRIMARY KEY (cache_key);


--
-- Name: comments_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_comment
    ADD CONSTRAINT comments_comment_pkey PRIMARY KEY (id);


--
-- Name: comments_commenthighlight_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_commenthighlight
    ADD CONSTRAINT comments_commenthighlight_pkey PRIMARY KEY (id);


--
-- Name: comments_commentrecommendations_comment_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_commentrecommendations
    ADD CONSTRAINT comments_commentrecommendations_comment_id_key UNIQUE (comment_id);


--
-- Name: comments_commentrecommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_commentrecommendations
    ADD CONSTRAINT comments_commentrecommendations_pkey PRIMARY KEY (id);


--
-- Name: comments_discussion_key_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_discussion
    ADD CONSTRAINT comments_discussion_key_key UNIQUE (key);


--
-- Name: comments_discussion_namespace_id_1e11383113e1ee6d_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_discussion
    ADD CONSTRAINT comments_discussion_namespace_id_1e11383113e1ee6d_uniq UNIQUE (namespace_id, key);


--
-- Name: comments_discussion_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_discussion
    ADD CONSTRAINT comments_discussion_pkey PRIMARY KEY (id);


--
-- Name: comments_discussion_tags_discussion_id_4e76b889f0b6619c_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_discussion_tags
    ADD CONSTRAINT comments_discussion_tags_discussion_id_4e76b889f0b6619c_uniq UNIQUE (discussion_id, tag_id);


--
-- Name: comments_discussion_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_discussion_tags
    ADD CONSTRAINT comments_discussion_tags_pkey PRIMARY KEY (id);


--
-- Name: comments_namespace_name_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_namespace
    ADD CONSTRAINT comments_namespace_name_key UNIQUE (name);


--
-- Name: comments_namespace_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_namespace
    ADD CONSTRAINT comments_namespace_pkey PRIMARY KEY (id);


--
-- Name: comments_rating_discussion_id_548f5958da064c9_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_rating
    ADD CONSTRAINT comments_rating_discussion_id_548f5958da064c9_uniq UNIQUE (discussion_id, rated_by_id);


--
-- Name: comments_rating_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_rating
    ADD CONSTRAINT comments_rating_pkey PRIMARY KEY (id);


--
-- Name: comments_tag_namespace_id_681b0d0b7e158899_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_tag
    ADD CONSTRAINT comments_tag_namespace_id_681b0d0b7e158899_uniq UNIQUE (namespace_id, path);


--
-- Name: comments_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY comments_tag
    ADD CONSTRAINT comments_tag_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: importer_pluckimportedcomment_action_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedcomment
    ADD CONSTRAINT importer_pluckimportedcomment_action_id_key UNIQUE (action_id);


--
-- Name: importer_pluckimportedcomment_comment_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedcomment
    ADD CONSTRAINT importer_pluckimportedcomment_comment_id_key UNIQUE (comment_id);


--
-- Name: importer_pluckimportedcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedcomment
    ADD CONSTRAINT importer_pluckimportedcomment_pkey PRIMARY KEY (id);


--
-- Name: importer_pluckimportedcomment_pluck_comment_key_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedcomment
    ADD CONSTRAINT importer_pluckimportedcomment_pluck_comment_key_key UNIQUE (pluck_comment_key);


--
-- Name: importer_pluckimportedrating_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedrating
    ADD CONSTRAINT importer_pluckimportedrating_pkey PRIMARY KEY (id);


--
-- Name: importer_pluckimportedrating_pluck_rating_key_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedrating
    ADD CONSTRAINT importer_pluckimportedrating_pluck_rating_key_key UNIQUE (pluck_rating_key);


--
-- Name: importer_pluckimportedrecommendati_pluck_recommendation_key_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedrecommendation
    ADD CONSTRAINT importer_pluckimportedrecommendati_pluck_recommendation_key_key UNIQUE (pluck_recommendation_key);


--
-- Name: importer_pluckimportedrecommendation_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedrecommendation
    ADD CONSTRAINT importer_pluckimportedrecommendation_pkey PRIMARY KEY (id);


--
-- Name: importer_pluckimportedreview_comment_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedreview
    ADD CONSTRAINT importer_pluckimportedreview_comment_id_key UNIQUE (comment_id);


--
-- Name: importer_pluckimportedreview_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedreview
    ADD CONSTRAINT importer_pluckimportedreview_pkey PRIMARY KEY (id);


--
-- Name: importer_pluckimportedreview_pluck_review_key_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY importer_pluckimportedreview
    ADD CONSTRAINT importer_pluckimportedreview_pluck_review_key_key UNIQUE (pluck_review_key);


--
-- Name: jogging_log_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY jogging_log
    ADD CONSTRAINT jogging_log_pkey PRIMARY KEY (id);


--
-- Name: moderation_abusecategory_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_abusecategory
    ADD CONSTRAINT moderation_abusecategory_pkey PRIMARY KEY (id);


--
-- Name: moderation_abusereport_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_abusereport
    ADD CONSTRAINT moderation_abusereport_pkey PRIMARY KEY (id);


--
-- Name: moderation_action_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT moderation_action_pkey PRIMARY KEY (id);


--
-- Name: moderation_applicationpermissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_applicationpermissions
    ADD CONSTRAINT moderation_applicationpermissions_pkey PRIMARY KEY (id);


--
-- Name: moderation_ipaddressnotes_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_ipaddressnotes
    ADD CONSTRAINT moderation_ipaddressnotes_pkey PRIMARY KEY (id);


--
-- Name: moderation_ipsblockedfromreportingabuse_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_ipsblockedfromreportingabuse
    ADD CONSTRAINT moderation_ipsblockedfromreportingabuse_pkey PRIMARY KEY (id);


--
-- Name: moderation_moderatorprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_moderatorprofile
    ADD CONSTRAINT moderation_moderatorprofile_pkey PRIMARY KEY (id);


--
-- Name: moderation_queues_moderationqueue_code_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_queues_moderationqueue
    ADD CONSTRAINT moderation_queues_moderationqueue_code_uniq UNIQUE (code);


--
-- Name: moderation_queues_moderationqueue_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_queues_moderationqueue
    ADD CONSTRAINT moderation_queues_moderationqueue_pkey PRIMARY KEY (id);


--
-- Name: moderation_queues_moderationrequest_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_queues_moderationrequest
    ADD CONSTRAINT moderation_queues_moderationrequest_pkey PRIMARY KEY (id);


--
-- Name: moderation_queues_moderationrequest_request_hash_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_queues_moderationrequest
    ADD CONSTRAINT moderation_queues_moderationrequest_request_hash_uniq UNIQUE (request_hash);


--
-- Name: moderation_sanction_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY moderation_sanction
    ADD CONSTRAINT moderation_sanction_pkey PRIMARY KEY (id);


--
-- Name: profiles_badge_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY profiles_badge
    ADD CONSTRAINT profiles_badge_pkey PRIMARY KEY (id);


--
-- Name: profiles_profile_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY profiles_profile_badges
    ADD CONSTRAINT profiles_profile_badges_pkey PRIMARY KEY (id);


--
-- Name: profiles_profile_badges_profile_id_2c36ddcdf89ea09a_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY profiles_profile_badges
    ADD CONSTRAINT profiles_profile_badges_profile_id_2c36ddcdf89ea09a_uniq UNIQUE (profile_id, badge_id);


--
-- Name: profiles_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY profiles_profile
    ADD CONSTRAINT profiles_profile_pkey PRIMARY KEY (id);


--
-- Name: profiles_profile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY profiles_profile
    ADD CONSTRAINT profiles_profile_user_id_key UNIQUE (user_id);


--
-- Name: profiles_profile_vanity_url_key; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY profiles_profile
    ADD CONSTRAINT profiles_profile_vanity_url_key UNIQUE (vanity_url);


--
-- Name: recommendations_recommendation_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY recommendations_recommendation
    ADD CONSTRAINT recommendations_recommendation_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: switchboard_state_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY switchboard_state
    ADD CONSTRAINT switchboard_state_pkey PRIMARY KEY (id);


--
-- Name: switchboard_switch_name_uniq; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY switchboard_switch
    ADD CONSTRAINT switchboard_switch_name_uniq UNIQUE (name);


--
-- Name: switchboard_switch_pkey; Type: CONSTRAINT; Schema: public; Owner: pgowner; Tablespace: 
--

ALTER TABLE ONLY switchboard_switch
    ADD CONSTRAINT switchboard_switch_pkey PRIMARY KEY (id);


--
-- Name: antispam_badword_created_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX antispam_badword_created_by_id ON antispam_badword USING btree (created_by_id);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_message_user_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_message_user_id ON auth_message USING btree (user_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: avatars_avatar_created_on; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX avatars_avatar_created_on ON avatars_avatar USING btree (created_on);


--
-- Name: avatars_avatar_is_communal; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX avatars_avatar_is_communal ON avatars_avatar USING btree (is_communal);


--
-- Name: avatars_avatar_profile_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX avatars_avatar_profile_id ON avatars_avatar USING btree (profile_id);


--
-- Name: avatars_avatar_requires_moderation; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX avatars_avatar_requires_moderation ON avatars_avatar USING btree (requires_moderation);


--
-- Name: avatars_avatar_status; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX avatars_avatar_status ON avatars_avatar USING btree (status);


--
-- Name: avatars_avatar_status_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX avatars_avatar_status_like ON avatars_avatar USING btree (status varchar_pattern_ops);


--
-- Name: cachetable_expires; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX cachetable_expires ON cachetable USING btree (expires);


--
-- Name: comments_comment_common_ancestor_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_common_ancestor_id ON comments_comment USING btree (common_ancestor_id);


--
-- Name: comments_comment_created_on; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_created_on ON comments_comment USING btree (created_on);


--
-- Name: comments_comment_discussion_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_discussion_id ON comments_comment USING btree (discussion_id);


--
-- Name: comments_comment_discussion_id_38e24964784b4e6f; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_discussion_id_38e24964784b4e6f ON comments_comment USING btree (discussion_id, created_on);


--
-- Name: comments_comment_discussion_id_3a4da9d2e640130f; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_discussion_id_3a4da9d2e640130f ON comments_comment USING btree (discussion_id, status);


--
-- Name: comments_comment_dn_in_reply_to_profile_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_dn_in_reply_to_profile_id ON comments_comment USING btree (dn_in_reply_to_profile_id);


--
-- Name: comments_comment_in_reply_to_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_in_reply_to_id ON comments_comment USING btree (in_reply_to_id);


--
-- Name: comments_comment_is_flagged; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_is_flagged ON comments_comment USING btree (is_flagged);


--
-- Name: comments_comment_last_updated; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_last_updated ON comments_comment USING btree (last_updated);


--
-- Name: comments_comment_posted_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_posted_by_id ON comments_comment USING btree (posted_by_id);


--
-- Name: comments_comment_posted_by_id_34f5d0d83981371; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_posted_by_id_34f5d0d83981371 ON comments_comment USING btree (posted_by_id, created_on);


--
-- Name: comments_comment_posted_by_ip; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_posted_by_ip ON comments_comment USING btree (posted_by_ip);


--
-- Name: comments_comment_posted_by_ip_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_posted_by_ip_like ON comments_comment USING btree (posted_by_ip varchar_pattern_ops);


--
-- Name: comments_comment_status; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_status ON comments_comment USING btree (status);


--
-- Name: comments_comment_status_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_comment_status_like ON comments_comment USING btree (status varchar_pattern_ops);


--
-- Name: comments_commenthighlight_comment_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_commenthighlight_comment_id ON comments_commenthighlight USING btree (comment_id);


--
-- Name: comments_commenthighlight_comment_posted_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_commenthighlight_comment_posted_by_id ON comments_commenthighlight USING btree (comment_posted_by_id);


--
-- Name: comments_commenthighlight_highlighted_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_commenthighlight_highlighted_by_id ON comments_commenthighlight USING btree (highlighted_by_id);


--
-- Name: comments_discussion_closed_after; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_closed_after ON comments_discussion USING btree (closed_after);


--
-- Name: comments_discussion_created_on; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_created_on ON comments_discussion USING btree (created_on);


--
-- Name: comments_discussion_creating_comment_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_creating_comment_id ON comments_discussion USING btree (creating_comment_id);


--
-- Name: comments_discussion_last_updated; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_last_updated ON comments_discussion USING btree (last_updated);


--
-- Name: comments_discussion_latest_visible_comment_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_latest_visible_comment_id ON comments_discussion USING btree (latest_visible_comment_id);


--
-- Name: comments_discussion_latest_visible_comment_id_456d723de093b44a; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_latest_visible_comment_id_456d723de093b44a ON comments_discussion USING btree (latest_visible_comment_id, namespace_id);


--
-- Name: comments_discussion_namespace_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_namespace_id ON comments_discussion USING btree (namespace_id);


--
-- Name: comments_discussion_primary_tag_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_primary_tag_id ON comments_discussion USING btree (primary_tag_id);


--
-- Name: comments_discussion_status; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_status ON comments_discussion USING btree (status);


--
-- Name: comments_discussion_status_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_status_like ON comments_discussion USING btree (status varchar_pattern_ops);


--
-- Name: comments_discussion_tags_discussion_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_tags_discussion_id ON comments_discussion_tags USING btree (discussion_id);


--
-- Name: comments_discussion_tags_tag_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_discussion_tags_tag_id ON comments_discussion_tags USING btree (tag_id);


--
-- Name: comments_namespace_site_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_namespace_site_id ON comments_namespace USING btree (site_id);


--
-- Name: comments_rating_discussion_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_rating_discussion_id ON comments_rating USING btree (discussion_id);


--
-- Name: comments_rating_last_updated; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_rating_last_updated ON comments_rating USING btree (last_updated);


--
-- Name: comments_rating_rated_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_rating_rated_by_id ON comments_rating USING btree (rated_by_id);


--
-- Name: comments_tag_last_updated; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_tag_last_updated ON comments_tag USING btree (last_updated);


--
-- Name: comments_tag_namespace_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_tag_namespace_id ON comments_tag USING btree (namespace_id);


--
-- Name: comments_tag_path; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_tag_path ON comments_tag USING btree (path);


--
-- Name: comments_tag_path_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX comments_tag_path_like ON comments_tag USING btree (path varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: importer_pluckimportedrating_rating_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX importer_pluckimportedrating_rating_id ON importer_pluckimportedrating USING btree (rating_id);


--
-- Name: moderation_abusereport_accused_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_abusereport_accused_id ON moderation_abusereport USING btree (accused_id);


--
-- Name: moderation_abusereport_category_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_abusereport_category_id ON moderation_abusereport USING btree (category_id);


--
-- Name: moderation_abusereport_comment_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_abusereport_comment_id ON moderation_abusereport USING btree (comment_id);


--
-- Name: moderation_abusereport_created_at; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_abusereport_created_at ON moderation_abusereport USING btree (created_on);


--
-- Name: moderation_abusereport_reported_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_abusereport_reported_by_id ON moderation_abusereport USING btree (reported_by_id);


--
-- Name: moderation_abusereport_status; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_abusereport_status ON moderation_abusereport USING btree (status);


--
-- Name: moderation_abusereport_status_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_abusereport_status_like ON moderation_abusereport USING btree (status varchar_pattern_ops);


--
-- Name: moderation_action_abuse_report_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_abuse_report_id ON moderation_action USING btree (abuse_report_id);


--
-- Name: moderation_action_avatar_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_avatar_id ON moderation_action USING btree (avatar_id);


--
-- Name: moderation_action_comment_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_comment_id ON moderation_action USING btree (comment_id);


--
-- Name: moderation_action_created_at; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_created_at ON moderation_action USING btree (created_on);


--
-- Name: moderation_action_discussion_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_discussion_id ON moderation_action USING btree (discussion_id);


--
-- Name: moderation_action_moderator_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_moderator_id ON moderation_action USING btree (moderator_id);


--
-- Name: moderation_action_profile_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_profile_id ON moderation_action USING btree (profile_id);


--
-- Name: moderation_action_sanction_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_action_sanction_id ON moderation_action USING btree (sanction_id);


--
-- Name: moderation_ipaddressnotes_ip_address; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_ipaddressnotes_ip_address ON moderation_ipaddressnotes USING btree (ip_address);


--
-- Name: moderation_ipaddressnotes_ip_address_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_ipaddressnotes_ip_address_like ON moderation_ipaddressnotes USING btree (ip_address varchar_pattern_ops);


--
-- Name: moderation_ipaddressnotes_moderator_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_ipaddressnotes_moderator_id ON moderation_ipaddressnotes USING btree (moderator_id);


--
-- Name: moderation_ipsblockedfromreportingabuse_ip; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_ipsblockedfromreportingabuse_ip ON moderation_ipsblockedfromreportingabuse USING btree (ip);


--
-- Name: moderation_ipsblockedfromreportingabuse_ip_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_ipsblockedfromreportingabuse_ip_like ON moderation_ipsblockedfromreportingabuse USING btree (ip varchar_pattern_ops);


--
-- Name: moderation_ipsblockedfromreportingabuse_moderator_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_ipsblockedfromreportingabuse_moderator_id ON moderation_ipsblockedfromreportingabuse USING btree (moderator_id);


--
-- Name: moderation_moderatorprofile_profile_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_moderatorprofile_profile_id ON moderation_moderatorprofile USING btree (profile_id);


--
-- Name: moderation_moderatorprofile_user_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_moderatorprofile_user_id ON moderation_moderatorprofile USING btree (user_id);


--
-- Name: moderation_queues_moderationrequest_discussion_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_queues_moderationrequest_discussion_id ON moderation_queues_moderationrequest USING btree (discussion_id);


--
-- Name: moderation_queues_moderationrequest_moderator_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_queues_moderationrequest_moderator_id ON moderation_queues_moderationrequest USING btree (moderator_id);


--
-- Name: moderation_queues_moderationrequest_queue_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_queues_moderationrequest_queue_id ON moderation_queues_moderationrequest USING btree (queue_id);


--
-- Name: moderation_sanction_created_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_sanction_created_by_id ON moderation_sanction USING btree (created_by_id);


--
-- Name: moderation_sanction_sanction_type; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_sanction_sanction_type ON moderation_sanction USING btree (sanction_type);


--
-- Name: moderation_sanction_sanction_type_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_sanction_sanction_type_like ON moderation_sanction USING btree (sanction_type varchar_pattern_ops);


--
-- Name: moderation_sanction_sanction_until; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_sanction_sanction_until ON moderation_sanction USING btree (sanction_until);


--
-- Name: moderation_sanction_user_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX moderation_sanction_user_id ON moderation_sanction USING btree (user_id);


--
-- Name: profiles_profile_badges_badge_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_badges_badge_id ON profiles_profile_badges USING btree (badge_id);


--
-- Name: profiles_profile_badges_profile_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_badges_profile_id ON profiles_profile_badges USING btree (profile_id);


--
-- Name: profiles_profile_created_on; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_created_on ON profiles_profile USING btree (created_on);


--
-- Name: profiles_profile_current_avatar_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_current_avatar_id ON profiles_profile USING btree (current_avatar_id);


--
-- Name: profiles_profile_is_social; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_is_social ON profiles_profile USING btree (is_social);


--
-- Name: profiles_profile_last_ip_address; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_last_ip_address ON profiles_profile USING btree (last_ip_address);


--
-- Name: profiles_profile_last_ip_address_like; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_last_ip_address_like ON profiles_profile USING btree (last_ip_address varchar_pattern_ops);


--
-- Name: profiles_profile_total_comment_count; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_total_comment_count ON profiles_profile USING btree (total_comment_count);


--
-- Name: profiles_profile_user_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_user_id ON profiles_profile USING btree (user_id);


--
-- Name: profiles_profile_vanity_url; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX profiles_profile_vanity_url ON profiles_profile USING btree (vanity_url);


--
-- Name: recommendations_recommendation_comment_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX recommendations_recommendation_comment_id ON recommendations_recommendation USING btree (comment_id);


--
-- Name: recommendations_recommendation_recommended_by_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX recommendations_recommendation_recommended_by_id ON recommendations_recommendation USING btree (recommended_by_id);


--
-- Name: switchboard_state_switch_id; Type: INDEX; Schema: public; Owner: pgowner; Tablespace: 
--

CREATE INDEX switchboard_state_switch_id ON switchboard_state USING btree (switch_id);


--
-- Name: abuse_report_id_refs_id_2988495895dddc2e; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT abuse_report_id_refs_id_2988495895dddc2e FOREIGN KEY (abuse_report_id) REFERENCES moderation_abusereport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accused_id_refs_id_37217111265eb8dc; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_abusereport
    ADD CONSTRAINT accused_id_refs_id_37217111265eb8dc FOREIGN KEY (accused_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: action_id_refs_id_12bb42afd1257175; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedcomment
    ADD CONSTRAINT action_id_refs_id_12bb42afd1257175 FOREIGN KEY (action_id) REFERENCES moderation_action(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_message_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: avatar_id_refs_id_466e633decfc5f81; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT avatar_id_refs_id_466e633decfc5f81 FOREIGN KEY (avatar_id) REFERENCES avatars_avatar(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: badge_id_refs_id_53b95d8cb3e69a35; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY profiles_profile_badges
    ADD CONSTRAINT badge_id_refs_id_53b95d8cb3e69a35 FOREIGN KEY (badge_id) REFERENCES profiles_badge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: category_id_refs_id_26aa4fe00b91cbc9; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_abusereport
    ADD CONSTRAINT category_id_refs_id_26aa4fe00b91cbc9 FOREIGN KEY (category_id) REFERENCES moderation_abusecategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_1dd01da63e55c731; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT comment_id_refs_id_1dd01da63e55c731 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_2211788ac1c891f2; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_commenthighlight
    ADD CONSTRAINT comment_id_refs_id_2211788ac1c891f2 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_27b7ee8904c1b13; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_queues_moderationrequest
    ADD CONSTRAINT comment_id_refs_id_27b7ee8904c1b13 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_28ed674d7b1b4724; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_abusereport
    ADD CONSTRAINT comment_id_refs_id_28ed674d7b1b4724 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_4f0a8e25c3bfa4f4; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_commentrecommendations
    ADD CONSTRAINT comment_id_refs_id_4f0a8e25c3bfa4f4 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_6441e2cf0e269e43; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedreview
    ADD CONSTRAINT comment_id_refs_id_6441e2cf0e269e43 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_653e891137f9a181; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY recommendations_recommendation
    ADD CONSTRAINT comment_id_refs_id_653e891137f9a181 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_id_refs_id_68dbaee279080207; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedcomment
    ADD CONSTRAINT comment_id_refs_id_68dbaee279080207 FOREIGN KEY (comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_posted_by_id_refs_id_4480c5be3b069bfa; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_commenthighlight
    ADD CONSTRAINT comment_posted_by_id_refs_id_4480c5be3b069bfa FOREIGN KEY (comment_posted_by_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: created_by_id_refs_id_11c9b6321c566ce1; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_sanction
    ADD CONSTRAINT created_by_id_refs_id_11c9b6321c566ce1 FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: created_by_id_refs_id_37574aff78f4ce57; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY antispam_badword
    ADD CONSTRAINT created_by_id_refs_id_37574aff78f4ce57 FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: creating_comment_id_refs_id_1fca803b6e61b527; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion
    ADD CONSTRAINT creating_comment_id_refs_id_1fca803b6e61b527 FOREIGN KEY (creating_comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: current_avatar_id_refs_id_5e2be1fbe11cf5db; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY profiles_profile
    ADD CONSTRAINT current_avatar_id_refs_id_5e2be1fbe11cf5db FOREIGN KEY (current_avatar_id) REFERENCES avatars_avatar(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussion_id_refs_id_26a61b8ebd46315; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_comment
    ADD CONSTRAINT discussion_id_refs_id_26a61b8ebd46315 FOREIGN KEY (discussion_id) REFERENCES comments_discussion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussion_id_refs_id_380556b396e63071; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT discussion_id_refs_id_380556b396e63071 FOREIGN KEY (discussion_id) REFERENCES comments_discussion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussion_id_refs_id_449eaad17fc7f532; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion_tags
    ADD CONSTRAINT discussion_id_refs_id_449eaad17fc7f532 FOREIGN KEY (discussion_id) REFERENCES comments_discussion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussion_id_refs_id_4acaede2360ed6dc; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_rating
    ADD CONSTRAINT discussion_id_refs_id_4acaede2360ed6dc FOREIGN KEY (discussion_id) REFERENCES comments_discussion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussion_id_refs_id_b297a5a878a7d4b; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_queues_moderationrequest
    ADD CONSTRAINT discussion_id_refs_id_b297a5a878a7d4b FOREIGN KEY (discussion_id) REFERENCES comments_discussion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_3cea63fe; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_3cea63fe FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: highlighted_by_id_refs_id_4480c5be3b069bfa; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_commenthighlight
    ADD CONSTRAINT highlighted_by_id_refs_id_4480c5be3b069bfa FOREIGN KEY (highlighted_by_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: latest_visible_comment_id_refs_id_1fca803b6e61b527; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion
    ADD CONSTRAINT latest_visible_comment_id_refs_id_1fca803b6e61b527 FOREIGN KEY (latest_visible_comment_id) REFERENCES comments_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: moderator_id_refs_id_3f3a2f5954a9e9e2; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_queues_moderationrequest
    ADD CONSTRAINT moderator_id_refs_id_3f3a2f5954a9e9e2 FOREIGN KEY (moderator_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: moderator_id_refs_id_4530472607be015e; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_ipsblockedfromreportingabuse
    ADD CONSTRAINT moderator_id_refs_id_4530472607be015e FOREIGN KEY (moderator_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: moderator_id_refs_id_49788360712e942a; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_ipaddressnotes
    ADD CONSTRAINT moderator_id_refs_id_49788360712e942a FOREIGN KEY (moderator_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: moderator_id_refs_id_6b5a2258500626ec; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT moderator_id_refs_id_6b5a2258500626ec FOREIGN KEY (moderator_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: namespace_id_refs_id_535b042a1cd85e34; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_tag
    ADD CONSTRAINT namespace_id_refs_id_535b042a1cd85e34 FOREIGN KEY (namespace_id) REFERENCES comments_namespace(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: namespace_id_refs_id_fd1b9a43cd4e3cd; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion
    ADD CONSTRAINT namespace_id_refs_id_fd1b9a43cd4e3cd FOREIGN KEY (namespace_id) REFERENCES comments_namespace(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: posted_by_id_refs_id_2c9ac73586c3c6fb; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_comment
    ADD CONSTRAINT posted_by_id_refs_id_2c9ac73586c3c6fb FOREIGN KEY (posted_by_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: primary_tag_id_refs_id_698f495bb834ed0c; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion
    ADD CONSTRAINT primary_tag_id_refs_id_698f495bb834ed0c FOREIGN KEY (primary_tag_id) REFERENCES comments_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: profile_id_refs_id_24e6856d7bf25f6b; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY avatars_avatar
    ADD CONSTRAINT profile_id_refs_id_24e6856d7bf25f6b FOREIGN KEY (profile_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: profile_id_refs_id_4f6dcb4bf49e90d1; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY profiles_profile_badges
    ADD CONSTRAINT profile_id_refs_id_4f6dcb4bf49e90d1 FOREIGN KEY (profile_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: profile_id_refs_id_5f2b48735f55f457; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT profile_id_refs_id_5f2b48735f55f457 FOREIGN KEY (profile_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: profile_id_refs_id_70ace7459b768625; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_moderatorprofile
    ADD CONSTRAINT profile_id_refs_id_70ace7459b768625 FOREIGN KEY (profile_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue_id_refs_id_6e16697e04b41287; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_queues_moderationrequest
    ADD CONSTRAINT queue_id_refs_id_6e16697e04b41287 FOREIGN KEY (queue_id) REFERENCES moderation_queues_moderationqueue(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rated_by_id_refs_id_5d430b6ad4483d0a; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_rating
    ADD CONSTRAINT rated_by_id_refs_id_5d430b6ad4483d0a FOREIGN KEY (rated_by_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rating_id_refs_id_5b950fa78b71c4df; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedrating
    ADD CONSTRAINT rating_id_refs_id_5b950fa78b71c4df FOREIGN KEY (rating_id) REFERENCES comments_rating(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recommendation_id_refs_id_174bc773ddf8ccaa; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY importer_pluckimportedrecommendation
    ADD CONSTRAINT recommendation_id_refs_id_174bc773ddf8ccaa FOREIGN KEY (recommendation_id) REFERENCES recommendations_recommendation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recommended_by_id_refs_id_4e1baccaf2495e47; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY recommendations_recommendation
    ADD CONSTRAINT recommended_by_id_refs_id_4e1baccaf2495e47 FOREIGN KEY (recommended_by_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reported_by_id_refs_id_37217111265eb8dc; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_abusereport
    ADD CONSTRAINT reported_by_id_refs_id_37217111265eb8dc FOREIGN KEY (reported_by_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sanction_id_refs_id_7810128a16f08192; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_action
    ADD CONSTRAINT sanction_id_refs_id_7810128a16f08192 FOREIGN KEY (sanction_id) REFERENCES moderation_sanction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_448b353ed306902d; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_namespace
    ADD CONSTRAINT site_id_refs_id_448b353ed306902d FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: switch_id_refs_id_476f89ab98f8aa25; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY switchboard_state
    ADD CONSTRAINT switch_id_refs_id_476f89ab98f8aa25 FOREIGN KEY (switch_id) REFERENCES switchboard_switch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tag_id_refs_id_416d1f571c22ab47; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY comments_discussion_tags
    ADD CONSTRAINT tag_id_refs_id_416d1f571c22ab47 FOREIGN KEY (tag_id) REFERENCES comments_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_36d0b8b98643dc9c; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_sanction
    ADD CONSTRAINT user_id_refs_id_36d0b8b98643dc9c FOREIGN KEY (user_id) REFERENCES profiles_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_831107f1; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_831107f1 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_aa8f4260723c358; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY moderation_moderatorprofile
    ADD CONSTRAINT user_id_refs_id_aa8f4260723c358 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_f2045483; Type: FK CONSTRAINT; Schema: public; Owner: pgowner
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_f2045483 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

