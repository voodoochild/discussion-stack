Python microapp framework
=========================

Uses decorators.
