from distutils.core import setup
import os

setup(
    name='microapp-framework',
    version="build.%s" % (os.environ.get('BUILD_NUMBER','DEV')),
    author="guardian development team",
    author_email="simon.willison@guardian.co.uk",
    description='Microapp utilities for Django apps',
    packages=['microapp_framework','microapp_framework.templatetags'],
    py_modules=['tests'],
)
