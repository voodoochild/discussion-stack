import functools
from xml.etree import ElementTree as ET
import re, itertools, urlparse

key_re = re.compile('{([^}]+)}')

class Microapp(object):
    def __init__(self, name, provider='guardian.co.uk', response_class=None, http404_class=None, default_expiry=60, root_url_params=[]):
        if response_class is None or http404_class is None:
            from django.http import HttpResponse, Http404
            response_class = HttpResponse
            http404_class = Http404
            
        self.name = name
        self.provider = provider
        self._resources = []
        self._raw_resources = []
        self._components = []
        self._keys = []
        self.response_class = response_class
        self.http404_class = http404_class        
        self.default_expiry = default_expiry
        self.root_url_params = root_url_params
        
    def __call__(self, request, path):
        if path == 'microapp.xml':
            return self.response_class(
                self.to_xml(),
                content_type = 'application/xml; charset=utf8'
            )
        if self.root_url_params:
            resolved_root_params, path = self.split_root_url_params(path)
        else:
            resolved_root_params = None
        endpoint = self.resolve(path)
        
        if endpoint is None:
            raise self.http404_class
        
        kwargs = endpoint.extract_parameters(path, request.GET)
        if resolved_root_params:
            request.microapp_root_url_params = resolved_root_params
        else: 
            request.microapp_root_url_params = None
        response = endpoint.view_function(request, **kwargs)

        if 'Cache-Control' not in response:
            response['Cache-Control'] = "max-age=%d" % (self.default_expiry,)

        return response

    def split_root_url_params(self, path):
        number_of_root_url_params = len(self.root_url_params)
        bits = path.split('/', number_of_root_url_params)
        resolved_root_param_values = bits[0:number_of_root_url_params]
        path = bits[-1]
        resolved_root_params = {}
        return dict(zip(self.root_url_params, resolved_root_param_values)), path
                
    def resolve(self, path):
        for endpoint in itertools.chain(
            self._resources, self._raw_resources, self._components
        ):
            if endpoint.matches(path):
                return endpoint
        return None
    
    def to_xml(self):
        et = self.to_et()
        _indent_element_tree(et)
        return ET.tostring(et)
    
    def _endpoint(self, Klass, klass_args, endpoint_list):
        def decorator(fn):
            @functools.wraps(fn)
            def view_function(request, *args, **kwargs):
                return fn(request, *args, **kwargs)
            
            name = klass_args['name'] or fn.__name__
            klass_args['name'] = name
            klass_args['display_name'] = klass_args['display_name'] or name
            klass_args['view_function'] = view_function
            endpoint_list.append(Klass(**klass_args))
            return view_function
        return decorator
    
    def resource(self, cms_path_pattern, path, name=None, display_name=None):
        return self._endpoint(Resource, {
            'cms_path_pattern': cms_path_pattern,
            'path': path,
            'name': name,
            'display_name': display_name,
        }, self._resources)

    def raw_resource(self, cms_path_pattern, path, name=None, display_name=None):
        return self._endpoint(RawResource, {
            'cms_path_pattern': cms_path_pattern,
            'path': path,
            'name': name,
            'display_name': display_name,
        }, self._raw_resources)

    def component(self, path, widths, name=None, display_name=None):
        return self._endpoint(Component, {
            'widths': widths,
            'path': path,
            'name': name,
            'display_name': display_name,
        }, self._components)
    
    def add_key(self, name, display_name, external_reference_type):
        return self._keys.append(Key(name, display_name, external_reference_type))
    
    def to_et(self):
        microapp = ET.Element('microapp')
        microapp.attrib['name'] = self.name
        microapp.attrib['provider'] = self.provider
        
        for element_name, endpoints in (
            ('resources', self._resources),
            ('raw-resources', self._raw_resources),
            ('components', self._components),
            ('keys', self._keys),
        ):
            el = ET.Element(element_name)
            microapp.append(el)
            for endpoint in endpoints:
                el.append(endpoint.to_et())
            
        return microapp

class Endpoint(object):
    def __init__(self, path, name, display_name, view_function):
        self.path = path or ""
        self.name = name
        self.display_name = display_name
        self.view_function = view_function
        # Ugly code coming up - we should refactor this eventually
        bits = (path.split('?', 1) + [''])[:2]
        self._actual_path = bits[0]
        self._qs_path = bits[1]
        self._path_re = self._compile_path_re()
        self._qs_arguments_to_microapp_params = {}
        for key, value in dict(urlparse.parse_qsl(self._qs_path)).items():
            m = key_re.match(value)
            if m:
                param_type, param_name = m.group(1).split(':')
                self._qs_arguments_to_microapp_params[key] = param_name
    
    def _compile_path_re(self):
        return re.compile('^%s$' % key_re.sub('([^/]*)', self._actual_path))
    
    def matches(self, path):
        return bool(self._path_re.match(path))
    
    def extract_parameters(self, path, qs_dict=None):
        qs_dict = qs_dict or {}
        # First deal with parameters found in the path
        path_names = self._parameter_names(self._actual_path)
        path_values = self._path_re.match(path).groups()
        params = dict(zip(path_names, path_values))
        # Now deal with params from the query string
        for pair in self._qs_arguments_to_microapp_params.items():
            qs_name, param_name = pair
            params[param_name.replace('-', '_')] = qs_dict.get(qs_name, '')
        return params
    
    def _parameter_names(self, s):
        return [
            key.split(':')[1].replace('-', '_') for key in key_re.findall(s)
        ]
    
    def to_et(self):
        el = ET.Element(self.element_name)
        for key in ('path', 'name', 'display_name'):
            el.attrib[key.replace('_', '-')] = getattr(self, key)
        return el

class Key(object):
    element_name = 'key-definition'
    def __init__(self, name, display_name, external_reference_type):
        self.name = name
        self.display_name = display_name
        self.external_reference_type = external_reference_type
    
    def to_et(self):
        el = ET.Element(self.element_name)
        for key in ('name', 'display_name', 'external_reference_type'):
            value = getattr(self, key)
            if value:
                el.attrib[key.replace('_', '-')] = value
        return el
        
class Resource(Endpoint):
    element_name = 'resource-definition'
    
    def __init__(self, cms_path_pattern, path, name, display_name, view_function):
        super(Resource, self).__init__(
            path, name, display_name, view_function
        )
        self.cms_path_pattern = cms_path_pattern
    
    def to_et(self):
        el = super(Resource, self).to_et()
        el.attrib['cms-path-pattern'] = self.cms_path_pattern
        return el

class RawResource(Resource):
    element_name = 'raw-resource-definition'

class Component(Endpoint):
    element_name = 'component-definition'
    
    def __init__(self, path, name, display_name, widths, view_function):
        super(Component, self).__init__(
            path, name, display_name, view_function
        )
        self.widths = widths
    
    def to_et(self):
        el = super(Component, self).to_et()
        el.attrib['widths'] = ','.join( map(str, self.widths) )
        return el

def _indent_element_tree(elem, level=0):
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            _indent_element_tree(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i