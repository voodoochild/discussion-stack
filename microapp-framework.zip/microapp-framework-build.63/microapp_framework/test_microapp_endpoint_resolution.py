from microapp import Microapp
import unittest
from testing_mocks import *

class MicroappTest(unittest.TestCase):

    def setUp(self):
        self.m = m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)

        @m.resource(path = '{key:the-key}/another-term', cms_path_pattern='{key:the_key}/another-term')
        def resource_with_key_and_another_term(request, the_key):
            return HttpResponse('resource_with_key_and_another_term: %s' % the_key)
            
        @m.resource(path = '{key:the-key}', cms_path_pattern='{key:a_key}')
        def resource_with_key(request, the_key):
            return HttpResponse('resource_with_key: %s' % the_key)

    def test_microapp_can_resolve_paths_with_confusing_namespaces(self):
        request = MockRequest({})
        response = self.m(request, "key-value/another-term")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content, "resource_with_key_and_another_term: key-value")
        
if __name__ == '__main__':
    unittest.main()
