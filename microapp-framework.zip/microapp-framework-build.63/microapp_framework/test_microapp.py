from microapp import Microapp
import unittest
from testing_mocks import *

class MicroappTest(unittest.TestCase):

    def setUp(self):
        self.m = m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)

        @m.resource(path = 'foo/bar', cms_path_pattern='guardian/bar')
        def bar(request):
            return 'bar'

        @m.resource(path = 'foo/baz', cms_path_pattern='guardian/baz')
        def baz(request):
            return 'baz'

        @m.component(path = 'component/dogs', widths=[420, 620])
        def dogs(request):
            return 'dogs'

        @m.raw_resource(path = 'foo/raw-dog', cms_path_pattern='guardian/woof')
        def raw_dog(request):
            return 'raw dog!'
        
        m.add_key(display_name = 'key-display-name', name='microapp:key-name', external_reference_type='external_type')
        m.add_key(display_name = 'no-external-ref', name='microapp:key-name', external_reference_type=None)        

    def test_microapp_xml_metadata(self):
        et = self.m.to_et()
        self.assertEqual(et.attrib['name'], 'Test microapp')
        self.assertEqual(et.attrib['provider'], 'guardian.co.uk')
        self.assertEqual(et.tag, 'microapp')

    def test_microapp_xml_resources(self):
        et = self.m.to_et()
        resources = et.findall('resources/resource-definition')
        self.assertEqual(len(resources), 2)
        self.assertEqual(resources[0].attrib['path'], 'foo/bar')
        self.assertEqual(resources[1].attrib['path'], 'foo/baz')

        self.assertEqual(resources[0].attrib['cms-path-pattern'], 'guardian/bar')
        self.assertEqual(resources[1].attrib['cms-path-pattern'], 'guardian/baz')

        #check that default names are provied
        self.assertEqual(resources[0].attrib['name'], 'bar')
        self.assertEqual(resources[1].attrib['name'], 'baz')
        #check that default display-names are provied
        self.assertEqual(resources[0].attrib['display-name'], 'bar')
        self.assertEqual(resources[1].attrib['display-name'], 'baz')

    def test_microapp_xml_raw_resources(self):
        et = self.m.to_et()
        raw_resources = et.findall('raw-resources/raw-resource-definition')
        self.assertEqual(len(raw_resources), 1)
        self.assertEqual(raw_resources[0].attrib['path'], 'foo/raw-dog')
        self.assertEqual(raw_resources[0].attrib['cms-path-pattern'], 'guardian/woof')
        self.assertEqual(raw_resources[0].attrib['name'], 'raw_dog')
        self.assertEqual(raw_resources[0].attrib['display-name'], 'raw_dog')

    def test_microapp_tracks_resources(self):
        self.assertEqual(len(self.m._resources), 2)

    def test_microapp_can_render_components_as_xml(self):
        et = self.m.to_et()
        components = et.findall('components/component-definition')

        self.assertEqual(len(components), 1)
        self.assertEqual(components[0].attrib['path'], 'component/dogs')
        self.assertEqual(components[0].attrib['widths'], '420,620')

        #check that default names are provied
        self.assertEqual(components[0].attrib['name'], 'dogs')
        #check that default display-names are provied
        self.assertEqual(components[0].attrib['display-name'], 'dogs')

    def test_microapp_keys(self):
        et = self.m.to_et()
        keys = et.findall('keys/key-definition')
        self.assertEqual(len(keys), 2)
        self.assertEqual(keys[0].attrib['display-name'], 'key-display-name')
        self.assertEqual(keys[0].attrib['name'], 'microapp:key-name')
        self.assertEqual(keys[0].attrib['external-reference-type'], 'external_type')
        try:
            keys[0].attrib['path']
            self.fail("should not have 'path' attribute in Key definition")
        except KeyError:
            pass

    def test_microapp_keys_can_have_null_attributes(self):
        et = self.m.to_et()
        keys = et.findall('keys/key-definition')
        self.assertEqual(len(keys), 2)
        self.assert_('external-reference-type' not in keys[1].attrib)

if __name__ == '__main__':
    unittest.main()
