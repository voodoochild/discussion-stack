from django import template

register = template.Library()

class MicroappHrefNode(template.Node):
    def __init__(self, path):
        self.path = path
    def render(self, context):
        return "{microapp-href:http://%s%s}" % (
            context["request"].META["HTTP_HOST"],
            template.Template(self.path).render(context),
        )

@register.tag(name="microapp_href")
def do_microapp_href(parser, token):
    bits = token.split_contents()
    if len(bits) != 2:
        raise template.TemplateSyntaxError, "microapp_href tag requires one argument"

    path = bits[1]
    if not (path[0] == path[-1] and path[0] in ('"', "'")):
        raise template.TemplateSyntaxError, "microapp_href's argument should be in quotes"
        
    return MicroappHrefNode(path[1:-1])