import unittest
from microapp import Microapp
from testing_mocks import *

class test_microapp_caching(unittest.TestCase):

    def test_microapp_has_default_cache_expiry(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return HttpResponse("hello from my_resource_view!")

        request = MockRequest({})
        response = m(request, "resource/exciting_thing")
        self.assertEqual(response['Cache-Control'], "max-age=60")

    def test_microapp_endpoint_can_override_default_cache_expiry(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            response = HttpResponse("hello from my_resource_view!")
            response['Cache-Control'] = "max-age=666"
            return response

        request = MockRequest({})
        response = m(request, "resource/exciting_thing")
        self.assertEqual(response['Cache-Control'], "max-age=666")

if __name__ == '__main__':
    unittest.main()
