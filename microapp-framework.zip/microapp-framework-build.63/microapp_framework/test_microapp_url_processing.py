from microapp import Microapp
import unittest
from testing_mocks import *

class EndpointUrlProcessingTest(unittest.TestCase):

    def test_microapp_resource_returns_none_when_non_existant_path_requested(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return 'bar'
        
        self.assertEqual(m.resolve("resource/exciting_thingx"), None)
        self.assertEqual(m.resolve("resource/exciting_thing/1"), None)
        self.assertEqual(m.resolve("resource/lol/exciting_thing"), None)
        self.assertEqual(m.resolve("resource/0/exciting_thingx"), None)
        self.assertEqual(m.resolve("resource//exciting_thing"), None)
        self.assertEqual(m.resolve("exciting_thing"), None)
                                                
    def test_microapp_resource_resolves_request_without_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return 'bar'
        
        path = "resource/exciting_thing"
        endpoint = m.resolve(path)
        self.assertEqual(endpoint.view_function, my_resource_view)

    def test_microapp_component_resolves_request_without_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.component(path = 'component/awesome_stuff', widths=[420, 620])
        def my_component_view(request):
            return 'dogs'
            
        endpoint = m.resolve("component/awesome_stuff")
        self.assertEqual(endpoint.view_function, my_component_view)  
        
    def test_microapp_raw_resource_resolves_request_without_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.raw_resource(path = 'raw/raw_thing', cms_path_pattern='guardian/woof')
        def my_raw_resource_view(request):
            return 'raw dog'

        endpoint = m.resolve("raw/raw_thing")
        self.assertEqual(endpoint.view_function, my_raw_resource_view)

    def test_microapp_resource_resolves_request_with_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing?user={user-param:username}&page={context-param:page-url}', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return 'bar'
            
        endpoint = m.resolve("resource/exciting_thing?user=bobandjim&page=http://www.guardian.co.uk/pluck")
        self.assertEqual(endpoint.view_function, my_resource_view)
        self.assertEqual(2, len(endpoint.parameters))

    def test_microapp_component_resolves_request_with_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.component(path = 'component/awesome_stuff/{request-param:showallcomments}/{user-param:username}', widths=[420, 620])
        def my_component_view(request):
            return 'dogs'
            
        endpoint = m.resolve("component/awesome_stuff/true/jimandbob")
        self.assertEqual(endpoint.view_function, my_component_view)

    def test_microapp_raw_resource_resolves_request_with_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.raw_resource(path = 'raw/raw_thing/{user-param:username}?url={context-param:page-url}', cms_path_pattern='guardian/woof')
        def my_raw_resource_view(request):
            return 'raw dog'

        endpoint = m.resolve("raw/raw_thing/jimlovesbob")
        self.assertEqual(endpoint.view_function, my_raw_resource_view)

    def test_microapp_resource_resolves_request_for_microapp_with_multiple_endpoints(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.raw_resource(path = 'raw/raw_thing/{context-param:page-url}?user={user-param:username}', cms_path_pattern='guardian/woof')
        
        def my_raw_resource_view(request):
            return 'raw dog'
        @m.component(path = 'component/awesome_stuff/{request-param:showallcomments}/{user-param:username}/', widths=[420, 620])
        def my_component_view(request):
            return 'dogs'
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return 'bar'            
        @m.resource(path = 'resource/other_resource?page={context-param:page-url}', cms_path_pattern='guardian/bar')
        def my_other_resource_view(request):
            return 'bar'              
            
        endpoint = m.resolve("resource/other_resource")
        self.assertEqual(endpoint.view_function, my_other_resource_view)
        
    def test_microapp_resource_resolves_request_with_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing?user={user-param:username}&page={context-param:page-url}', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return 'bar'
            
        endpoint = m.resolve("resource/exciting_thing")
        self.assertEqual(endpoint.view_function, my_resource_view)

if __name__ == '__main__':
    unittest.main()
