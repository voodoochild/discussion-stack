import unittest

#microapp framework test suite
from test_microapp_invokation import *
from test_microapp import *
from test_microapp_url_processing import *
from test_endpoint_parameter_extraction import *
from test_microapp_caching import *
from test_microapp_endpoint_resolution import *

if __name__ == '__main__':
    unittest.main()