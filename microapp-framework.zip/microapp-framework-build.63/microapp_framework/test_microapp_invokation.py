from microapp import Microapp
import unittest
from testing_mocks import *

class RootUrlEndpointParameterExtractionTest(unittest.TestCase):

    def test_microapp_with_one_root_url_parameter_resolves(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404, root_url_params=['site'])
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return HttpResponse("hello from my_resource_view! site = %s" % request.microapp_root_url_params['site'])

        request = MockRequest({})
        response = m(request, "guardian.co.uk/resource/exciting_thing")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content, "hello from my_resource_view! site = guardian.co.uk")

    def test_microapp_with_two_root_url_parameter_resolves(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404, root_url_params=['site','environment'])
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return HttpResponse("hello from my_resource_view! site = %s env = %s" % (
                request.microapp_root_url_params['site'], 
                request.microapp_root_url_params['environment']
            ))

        request = MockRequest({})
        response = m(request, "guardian.co.uk/TEST/resource/exciting_thing")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content, "hello from my_resource_view! site = guardian.co.uk env = TEST")
            
class MicroappInvokationTest(unittest.TestCase):

    def test_microapp_resource_resolves_request_without_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return HttpResponse("hello from my_resource_view!")

        request = MockRequest({})
        response = m(request, "resource/exciting_thing")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content, "hello from my_resource_view!")

    def test_microapp_resource_resolves_request_with_restful_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing/{user-param:username}/{request-param:showallcomments}', cms_path_pattern='guardian/bar')
        def my_resource_view(request, username, showallcomments):
            return HttpResponse("user=%s, showall=%s" % (username, showallcomments))

        request = MockRequest({})
        response = m(request, "resource/exciting_thing/jimandbob/true")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content, "user=jimandbob, showall=true")
        
    def test_microapp_resource_resolves_request_with_named_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing?user={user-param:username}&pageurl={context-param:page-url}', cms_path_pattern='guardian/bar')
        def my_resource_view(request, username, page_url):
            return HttpResponse("user=%s, url=%s" % (username, page_url))

        request = MockRequest({"username": "jimandbob", "page_url": "http://www.guardian.co.uk/evil?death&horror=true"})
        response = m(request, "resource/exciting_thing")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content, "user=jimandbob, url=http://www.guardian.co.uk/evil?death&horror=true")
        

    def test_microapp_resource_resolves_request_with_named_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request, username, page_url):
            return None

        request = MockRequest({})
        self.assertRaises(Http404, m, request, 'non_existent/resource')
        
if __name__ == '__main__':
    unittest.main()
