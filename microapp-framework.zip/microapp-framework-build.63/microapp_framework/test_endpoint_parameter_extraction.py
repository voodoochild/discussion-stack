from microapp import Microapp
import unittest
from testing_mocks import *

class EndpointParameterExtractionTest(unittest.TestCase):

    def test_microapp_resource_resolves_request_without_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return 'bar'
        
        path = "resource/exciting_thing"
        parameters = m._resources[0].extract_parameters(path, {})
        self.assertEqual({}, parameters)

    def test_microapp_component_resolves_request_without_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.component(path = 'component/awesome_stuff', widths=[420, 620])
        def my_component_view(request):
            return 'dogs'
            
        path = "component/awesome_stuff"
        parameters = m._components[0].extract_parameters(path, {})
        self.assertEqual({}, parameters)        
        
    def test_microapp_raw_resource_resolves_request_without_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.raw_resource(path = 'raw/raw_thing', cms_path_pattern='guardian/woof')
        def my_raw_resource_view(request):
            return 'raw dog'

        path = "raw/raw_thing"
        parameters = m._raw_resources[0].extract_parameters(path, {})
        self.assertEqual({}, parameters)

    def test_microapp_resource_resolves_request_with_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.resource(path = 'resource/exciting_thing?user={user-param:username}&page={context-param:page-url}', cms_path_pattern='guardian/bar')
        def my_resource_view(request):
            return 'bar'
            
        path = "resource/exciting_thing"
        actual_parameters = m._resources[0].extract_parameters(path, {"user": "jimandbob", "page": "http://www.guardian.co.uk/community/jimandbob?blah=test"})
        
        self.assertEqual(
        {
            "username": "jimandbob",
            "page_url": "http://www.guardian.co.uk/community/jimandbob?blah=test"
        }, actual_parameters)
                
    def test_microapp_component_resolves_request_with_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.component(path = 'component/awesome_stuff/{request-param:showallcomments}/{user-param:username}/', widths=[0])
        def my_component_view(request):
            return 'dogs'

        path = "component/awesome_stuff/true/jimandbob/"
        actual_parameters = m._components[0].extract_parameters(path, {})
        
        self.assertEqual(
        {
            "showallcomments": "true",
            "username": "jimandbob"
        }, actual_parameters)
        
    def test_microapp_raw_resource_resolves_request_with_context_parameters(self):
        m = Microapp(name = 'Test microapp', response_class=HttpResponse, http404_class=Http404)
        @m.raw_resource(path = 'raw/raw_thing/{user-param:username}?url={context-param:page-url}', cms_path_pattern='guardian/woof')
        def my_raw_resource_view(request):
            return 'raw dog'

        path = "raw/raw_thing/jimandbob"
        actual_parameters = m._raw_resources[0].extract_parameters(path, {"url":"http://www.guardian.co.uk/fun"})
        
        self.assertEqual(
        {
            "page_url": "http://www.guardian.co.uk/fun",
            "username": "jimandbob"
        }, actual_parameters)

if __name__ == '__main__':
    unittest.main()
