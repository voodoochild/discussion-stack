class MockRequest(object):
    def __init__(self, parameters):
        self.GET = parameters            

class HttpResponse(dict):
    def __init__(self, content, content_type='text/html'):
        self.content = content
        self.content_type = content_type
        self.status_code = 200
        dict.__init__(self)

class Http404(Exception):
    pass